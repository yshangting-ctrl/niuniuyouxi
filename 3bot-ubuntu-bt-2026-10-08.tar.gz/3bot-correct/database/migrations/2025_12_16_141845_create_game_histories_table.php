<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('game_histories', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('telegram_id');
            $table->string('username')->nullable();
            $table->string('bet_type'); // 大, 小
            $table->decimal('bet_amount', 10, 2);
            $table->decimal('win_amount', 10, 2)->default(0); // 包含本金的返还总额 (例如下100赢了是200)
            $table->decimal('profit', 10, 2)->default(0); // 纯利润 (win_amount - bet_amount)
            $table->string('result_type')->nullable(); // 开奖结果: 大, 小, 豹子...
            $table->string('rolls')->nullable(); // 1,2,3
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('game_histories');
    }
};