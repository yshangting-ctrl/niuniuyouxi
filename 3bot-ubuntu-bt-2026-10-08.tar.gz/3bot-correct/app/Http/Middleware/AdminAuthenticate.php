<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminAuthenticate
{
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->session()->get('admin_authenticated', false)) {
            return $next($request);
        }

        return redirect()->guest(route('admin.login'))
            ->with('status', '请先登录管理员后台。');
    }
}
