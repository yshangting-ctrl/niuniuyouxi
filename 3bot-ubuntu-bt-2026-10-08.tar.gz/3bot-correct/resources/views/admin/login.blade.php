<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>登录 · 3Bot 运营控制台</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="login-shell">
    <main class="login-layout">
        <section class="login-intro">
            <div class="login-brand"><span class="brand-mark">3</span><span><strong>3BOT</strong><small>运营控制台</small></span></div>
            <div class="login-intro-copy">
                <p class="section-kicker">SECURE OPERATIONS</p>
                <h1>把每一局，<br>都放在掌控之中。</h1>
                <p>登录后台，查看玩家余额、游戏记录与 Telegram 机器人运行状态。</p>
            </div>
            <div class="login-feature-list">
                <div><span>01</span><strong>运营数据</strong><small>实时了解平台流水与玩家活跃度</small></div>
                <div><span>02</span><strong>账户管理</strong><small>安全完成玩家余额调整与审计</small></div>
                <div><span>03</span><strong>服务监控</strong><small>集中查看机器人与数据库状态</small></div>
            </div>
            <p class="login-copyright">3Bot Admin · Local control center</p>
        </section>

        <section class="login-panel">
            <div class="login-card">
                <div class="login-card-heading">
                    <p class="panel-eyebrow">ADMIN ACCESS</p>
                    <h2>欢迎回来</h2>
                    <p>使用管理员账号登录控制台</p>
                </div>

                @if (session('status'))
                    <div class="login-alert login-alert-success" role="status">✓ {{ session('status') }}</div>
                @endif
                @if ($errors->any())
                    <div class="login-alert login-alert-error" role="alert">{{ $errors->first() }}</div>
                @endif

                <form method="POST" action="{{ route('admin.login.submit') }}" class="login-form">
                    @csrf
                    <label class="login-label" for="login">管理员账号</label>
                    <div class="login-input-wrap"><span>◎</span><input id="login" name="login" type="text" value="{{ old('login') }}" autocomplete="username" placeholder="输入管理员 ID" required autofocus></div>

                    <label class="login-label" for="password">登录密码</label>
                    <div class="login-input-wrap"><span>⌑</span><input id="password" name="password" type="password" autocomplete="current-password" placeholder="输入登录密码" required></div>

                    <div class="captcha-heading"><label class="login-label" for="captcha">图形文字验证码</label><span>区分大小写</span></div>
                    <div class="captcha-row">
                        <div class="login-input-wrap captcha-input"><span>#</span><input id="captcha" name="captcha" type="text" inputmode="text" maxlength="5" autocomplete="off" placeholder="输入图片中的字符" required></div>
                        <button type="button" class="captcha-image-button" data-refresh-captcha title="刷新验证码" aria-label="刷新验证码"><img data-captcha-image src="{{ route('admin.captcha') }}?v={{ time() }}" alt="图形文字验证码"></button>
                    </div>
                    <button class="login-submit" type="submit">登录控制台 <span>→</span></button>
                </form>

                <div class="login-security-note"><span>◈</span><p>验证码有效期 5 分钟。请勿在公共设备保存登录信息。</p></div>
            </div>
        </section>
    </main>
</body>
</html>
