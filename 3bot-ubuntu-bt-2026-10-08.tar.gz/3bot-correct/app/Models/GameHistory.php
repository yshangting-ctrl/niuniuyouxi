<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameHistory extends Model
{
    use HasFactory;

    protected $fillable = [
        'telegram_id',
        'username',
        'bet_type',
        'bet_amount',
        'win_amount',
        'profit',
        'result_type',
        'rolls',
    ];
}