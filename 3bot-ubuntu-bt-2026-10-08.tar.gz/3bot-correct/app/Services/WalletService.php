<?php

namespace App\Services;

use Elliptic\EC;
use kornrunner\Keccak;
use StephenHill\Base58;
use Illuminate\Support\Facades\Crypt;

class WalletService
{
    /**
     * 生成新的Tron钱包
     */
    public function generateWallet(): array
    {
        // 初始化 secp256k1 椭圆曲线
        $ec = new EC('secp256k1');

        // 生成密钥对
        $keyPair = $ec->genKeyPair();
        $privateKey = $keyPair->getPrivate("hex");
        $publicKey = $keyPair->getPublic(false, "hex");

        // 对公钥进行 Keccak-256 哈希处理
        $hash = Keccak::hash(substr(hex2bin($publicKey), 1), 256);
        $addressHex = '41' . substr($hash, -40); // TRON地址前缀'41'

        $address = $this->base58checkEncode($addressHex);

        return [
            'address' => $address,
            'privateKey' => $privateKey,
            'publicKey' => $publicKey,
            'addressHex' => $addressHex,
        ];
    }

    /**
     * Base58Check编码
     */
    private function base58checkEncode($hex): string
    {
        $base58 = new Base58();
        $hexWithChecksum = $hex . substr(hash('sha256', hash('sha256', hex2bin($hex), true)), 0, 8);
        return $base58->encode(hex2bin($hexWithChecksum));
    }

    /**
     * 加密私钥
     */
    public function encryptPrivateKey(string $privateKey): string
    {
        return Crypt::encryptString($privateKey);
    }

    /**
     * 解密私钥
     */
    public function decryptPrivateKey(string $encryptedPrivateKey): string
    {
        return Crypt::decryptString($encryptedPrivateKey);
    }
}
