<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;

class AdminAuthController extends Controller
{
    public function showLogin(Request $request)
    {
        if ($request->session()->get('admin_authenticated', false)) {
            return redirect()->route('admin.dashboard');
        }

        return view('admin.login');
    }

    public function captcha(Request $request)
    {
        $characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $value = '';

        for ($index = 0; $index < 5; $index++) {
            $value .= $characters[random_int(0, strlen($characters) - 1)];
        }

        $request->session()->put('admin_captcha', [
            'value' => strtolower($value),
            'expires_at' => now()->addMinutes(5)->timestamp,
        ]);

        $colors = ['#0f766e', '#155e75', '#334155', '#7c3aed', '#b45309'];
        $text = '';
        for ($index = 0; $index < strlen($value); $index++) {
            $x = 32 + ($index * 31);
            $rotation = random_int(-13, 13);
            $color = $colors[$index % count($colors)];
            $text .= sprintf(
                '<text x="%d" y="39" fill="%s" transform="rotate(%d %d 39)">%s</text>',
                $x,
                $color,
                $rotation,
                $x,
                $value[$index]
            );
        }

        $noise = '';
        for ($index = 0; $index < 7; $index++) {
            $x1 = random_int(4, 176);
            $y1 = random_int(9, 51);
            $x2 = random_int(4, 176);
            $y2 = random_int(9, 51);
            $noise .= sprintf('<path d="M%d %d Q%d %d %d %d" />', $x1, $y1, random_int(20, 160), random_int(0, 60), $x2, $y2);
        }

        for ($index = 0; $index < 22; $index++) {
            $noise .= sprintf('<circle cx="%d" cy="%d" r="%d" />', random_int(4, 176), random_int(6, 54), random_int(1, 2));
        }

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="182" height="60" viewBox="0 0 182 60" role="img" aria-label="图形文字验证码">'
            . '<rect width="182" height="60" rx="9" fill="#f1f8f7"/>'
            . '<g fill="none" stroke="#8accc1" stroke-width="1" opacity=".55">' . $noise . '</g>'
            . '<g font-family="Arial, sans-serif" font-size="27" font-weight="700" letter-spacing="1">' . $text . '</g>'
            . '</svg>';

        return response($svg, 200, [
            'Content-Type' => 'image/svg+xml',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
        ]);
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'login' => ['required', 'string', 'max:100'],
            'password' => ['required', 'string', 'max:120'],
            'captcha' => ['required', 'string', 'size:5'],
        ], [
            'login.required' => '请输入管理员账号。',
            'password.required' => '请输入登录密码。',
            'captcha.required' => '请输入图形验证码。',
            'captcha.size' => '验证码应为 5 位字符。',
        ]);

        $captcha = $request->session()->pull('admin_captcha');
        $captchaValid = is_array($captcha)
            && !empty($captcha['value'])
            && ($captcha['expires_at'] ?? 0) >= now()->timestamp
            && hash_equals((string) $captcha['value'], Str::lower(trim($data['captcha'])));

        if (!$captchaValid) {
            return back()->withInput($request->only('login'))->withErrors(['captcha' => '验证码不正确或已过期，请刷新后重试。']);
        }

        $expectedLogin = (string) env('ADMIN_LOGIN_ID', '8539427848');
        $expectedPassword = (string) env('ADMIN_LOGIN_PASSWORD', 'change-me');
        $credentialsValid = hash_equals($expectedLogin, trim($data['login']))
            && hash_equals($expectedPassword, $data['password']);

        if (!$credentialsValid) {
            return back()->withInput($request->only('login'))->withErrors(['login' => '管理员账号或密码不正确。']);
        }

        $request->session()->regenerate();
        $request->session()->put([
            'admin_authenticated' => true,
            'admin_login' => $expectedLogin,
        ]);

        return redirect()->intended(route('admin.dashboard'))->with('status', '登录成功，欢迎回来。');
    }

    public function logout(Request $request)
    {
        $request->session()->forget(['admin_authenticated', 'admin_login']);
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('admin.login')->with('status', '你已安全退出后台。');
    }
}
