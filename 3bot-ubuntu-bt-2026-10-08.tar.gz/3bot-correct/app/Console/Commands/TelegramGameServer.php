<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\TelegramUser;
use App\Models\GameHistory;
use App\Models\TelegramGameSession;
use Illuminate\Support\Carbon;

class TelegramGameServer extends Command
{
    protected $signature = 'game:telegram-server';
    protected $description = 'Telegram Dice Game: User Rolls Mode with History & Stats';

    protected $botToken;
    protected $adminIds = [123456789]; 
    protected $apiUrl = 'https://api.telegram.org/bot';

    // 运行状态
    protected $isRunning = true; 
    protected $updateOffset = 0;
    
    // 用户会话数据
    protected $userSessions = [];

    // 赔率配置
    protected $odds = [
        // 单式 (Single Bet)
        'single_big_small' => 2.0,
        'single_odd_even' => 2.0,

        // 复式 (Compound Bet)
        'compound_big_odd' => 3.4,
        'compound_small_even' => 3.4,
        'compound_big_even' => 4.3,
        'compound_small_odd' => 4.3,

        // 特殊玩法 (Special Play)
        'special_pairs' => 2.0,
        'special_leopard' => 25.0,
        'special_straight' => 6.0,

        // 点杀玩法 (Point Kill Play)
        'point_kill_sum_4' => 38.0,
        'point_kill_sum_5' => 12.0, 
        'point_kill_sum_6' => 10.0, 
        'point_kill_sum_7' => 9.0,  
        'point_kill_sum_8' => 6.0,  
        'point_kill_sum_9' => 6.0,
        'point_kill_sum_10' => 6.0,
        'point_kill_sum_11' => 6.0,
        'point_kill_sum_12' => 6.0,
        'point_kill_sum_13' => 9.0,
        'point_kill_sum_14' => 10.0,
        'point_kill_sum_15' => 12.0,
        'point_kill_sum_16' => 18.0,
        'point_kill_sum_17' => 38.0,
        'point_kill_sum_18' => 66.0,

        // 补充特殊玩法：1-2-3 顺子
        'special_straight_123' => 66.0,

        // 点杀豹子玩法 (Point Kill Leopard Play)
        'point_kill_leopard' => 166.0,

        // 龙虎玩法 (Dragon-Tiger Play)
        'dragon_tiger_dragon_tiger' => 2.0,
        'dragon_tiger_tie' => 5.0,
    ];

    protected $niuniuOdds = [
        'five_bomb' => 16,
        'four_bomb' => 11,
        'straight' => 10,
        'three_bomb_niu' => 9,
        'full_house' => 8,
        'five_diff' => 7,
        'five_big_small' => 6,
        'niu_niu' => 5,
        'niu_9' => 4,
        'niu_8' => 3,
        'niu_7' => 2,
        'niu_normal' => 1, 
        'no_niu' => 1,     
    ];

    protected $sanGongOdds = [
        '散牌' => 1,
        '对子' => 3,
        '顺子' => 5,
        '豹子' => 8,
    ];

    protected $tongziOdds = [
        'normal_win' => 1, // 1:1 payout for normal wins
        'pair_win' => 1,   // Pairs also have 1:1 payout
    ];

    protected function calculateSanGongResult($dice) {
        sort($dice); // Sort dice for easier comparison of straights and pairs
        $sum = array_sum($dice);

        // Check for 豹子 (Triples)
        if ($dice[0] == $dice[1] && $dice[1] == $dice[2]) {
            return ['type' => '豹子', 'rank' => 4, 'value' => $dice[0], 'sum' => $sum];
        }

        // Check for 顺子 (Straight)
        if ($dice[0] + 1 == $dice[1] && $dice[1] + 1 == $dice[2]) {
            return ['type' => '顺子', 'rank' => 3, 'value' => $sum, 'sum' => $sum];
        }

        // Check for 对子 (Pair)
        // If there are two identical dice after sorting
        if ($dice[0] == $dice[1] || $dice[1] == $dice[2]) {
            $pairValue = 0;
            $thirdValue = 0;
            if ($dice[0] == $dice[1]) {
                $pairValue = $dice[0];
                $thirdValue = $dice[2];
            } else { // $dice[1] == $dice[2]
                $pairValue = $dice[1];
                $thirdValue = $dice[0];
            }
            return ['type' => '对子', 'rank' => 2, 'value' => $pairValue * 10 + $thirdValue, 'sum' => $sum]; // Combine pair and third for ranking
        }

        // 散牌 (Scattered/Non-paired)
        return ['type' => '散牌', 'rank' => 1, 'value' => $sum, 'sum' => $sum]; // Rank by sum for scattered cards
    }

    protected function calculateNiuResult($dice) {
        sort($dice);
        $sum = array_sum($dice);
        $counts = array_count_values($dice);
        $maxCount = max($counts);
        $isStraight = ($dice[0]+1 == $dice[1] && $dice[1]+1 == $dice[2] && $dice[2]+1 == $dice[3] && $dice[3]+1 == $dice[4]);
        
        // 1. Five Bomb
        if ($maxCount == 5) return ['rank' => 100, 'name' => '五炸', 'mul' => 16];
        
        // 2. Four Bomb
        if ($maxCount == 4) return ['rank' => 90, 'name' => '四炸', 'mul' => 11];
        
        // 3. Straight
        if ($isStraight) return ['rank' => 80, 'name' => '顺子牛', 'mul' => 10];
        
        // 4. Three Bomb Niu
        $threeVal = 0;
        foreach($counts as $k => $v) { if ($v == 3) $threeVal = $k; }
        if ($threeVal > 0) {
            $remSum = 0;
            foreach($dice as $d) { if ($d != $threeVal) $remSum += $d; }
            if ($remSum == 10) return ['rank' => 70, 'name' => '三炸牛牛', 'mul' => 9];
        }

        // 5. Full House
        if (count($counts) == 2 && ($maxCount == 3)) return ['rank' => 60, 'name' => '葫芦牛', 'mul' => 8];

        // 6. Five Different
        if (count($counts) == 5 && !$isStraight) return ['rank' => 50, 'name' => '五不同牛', 'mul' => 7];

        // 7. Five Small / Big
        $allSmall = true;
        $allBig = true;
        foreach($dice as $d) {
            if ($d > 3) $allSmall = false;
            if ($d < 4) $allBig = false;
        }
        if ($allSmall) return ['rank' => 45, 'name' => '五小牛', 'mul' => 6];
        if ($allBig) return ['rank' => 45, 'name' => '五大牛', 'mul' => 6];

        // 8. Niu Logic
        $maxNiuVal = -1; 
        for ($i=0; $i<3; $i++) {
            for ($j=$i+1; $j<4; $j++) {
                for ($k=$j+1; $k<5; $k++) {
                    $s = $dice[$i] + $dice[$j] + $dice[$k];
                    if ($s == 6 || $s == 12 || $s == 18) {
                        $remSum = $sum - $s;
                        $niu = ($remSum - 1) % 10 + 1;
                        if ($niu > $maxNiuVal) $maxNiuVal = $niu;
                    }
                }
            }
        }

        if ($maxNiuVal != -1) {
            if ($maxNiuVal == 10) return ['rank' => 30, 'name' => '牛牛', 'mul' => 5];
            if ($maxNiuVal == 9) return ['rank' => 29, 'name' => '牛九', 'mul' => 4];
            if ($maxNiuVal == 8) return ['rank' => 28, 'name' => '牛八', 'mul' => 3];
            if ($maxNiuVal == 7) return ['rank' => 27, 'name' => '牛七', 'mul' => 2];
            $names = ['', '牛一', '牛二', '牛三', '牛四', '牛五', '牛六'];
            return ['rank' => 20 + $maxNiuVal, 'name' => $names[$maxNiuVal], 'mul' => 1];
        }

        return ['rank' => 0, 'name' => '无牛', 'mul' => 1];
    }

    protected function calculateTongziResult($dice) {
        $sum = array_sum($dice);
        $points = $sum % 10;
        
        // Special case for 0 points (sum 10)
        if ($points === 0 && $sum === 10) {
            $points = 0; // Explicitly set to 0
        } elseif ($points === 0) { // Sums like 20, 30... if applicable with 2 dice (max 12)
            $points = 10; // This means a sum of 10 or 20 (which is impossible with 2 dice) will be 0 points, otherwise modulo is actual point value
        }

        // Check for 对子 (Pair)
        if ($dice[0] == $dice[1]) {
            return ['type' => '对子', 'pair_value' => $dice[0], 'points' => $points];
        }

        return ['type' => '散牌', 'pair_value' => 0, 'points' => $points];
    }

    public function handle()
    {
        $this->botToken = env('TELEGRAM_BOT_TOKEN');
        if (!$this->botToken) {
            $this->botToken = $this->ask('请输入 Telegram Bot Token');
        }

        $this->info("Telegram Game Server Started (User-Roll + Stats)...");
        $this->removeWebhook();
        $this->setBotCommands();
        $this->loadPersistedSessions();
        
        while (true) {
            try {
                // 始终处理更新，以接收管理员指令 (/start_game)
                $this->processUpdates();

                // 只有在运行时才检查超时
                if ($this->isRunning) {
                    $this->checkTimeouts();
                }

                usleep(100000); 
            } catch (\Exception $e) {
                $this->error("Error: " . $e->getMessage());
                sleep(2);
            }
        }
    }

    protected function removeWebhook()
    {
        try {
            $this->telegramHttp()->get("{$this->apiUrl}{$this->botToken}/deleteWebhook");
        } catch (\Exception $e) {}
    }

    protected function setBotCommands()
    {
        try {
            $commands = [
                ['command' => 'start', 'description' => '打开功能菜单'],
                ['command' => 'menu', 'description' => '显示功能菜单'],
                ['command' => 'balance', 'description' => '查询余额'],
                ['command' => 'cancel', 'description' => '取消当前下注'],
                ['command' => 'recharge', 'description' => '获取充值地址'],
                ['command' => 'history', 'description' => '查看游戏记录'],
                ['command' => 'help', 'description' => '查看使用说明'],
            ];

            $this->telegramHttp()->post("{$this->apiUrl}{$this->botToken}/setMyCommands", [
                'commands' => json_encode($commands, JSON_UNESCAPED_UNICODE),
            ]);
        } catch (\Exception $e) {
            $this->warn('Telegram command menu setup failed: ' . $e->getMessage());
        }
    }

    protected function telegramHttp()
    {
        $options = [];
        $proxy = env('TELEGRAM_HTTP_PROXY');
        $caBundle = env('TELEGRAM_HTTP_CA_BUNDLE');

        if ($caBundle && !preg_match('/^(?:[A-Za-z]:[\\\\\/]|\/)/', $caBundle)) {
            $caBundle = base_path(str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $caBundle));
        }

        if ($proxy) {
            $options['proxy'] = $proxy;
        }
        if ($caBundle) {
            $options['verify'] = $caBundle;
        }

        $request = Http::timeout((int) env('TELEGRAM_HTTP_TIMEOUT', 30));
        return $options ? $request->withOptions($options) : $request;
    }

    protected function checkTimeouts()
    {
        $now = time();
        foreach ($this->userSessions as $userId => $session) {
            $requiredRolls = $this->getSessionRequiredRolls($session);
            if (!empty($session['rolls']) && count($session['rolls']) < $requiredRolls) {
                if (isset($session['first_roll_time']) && ($now - $session['first_roll_time'] >= 180)) {
                    $this->handleForfeit($userId, $session);
                }
            }
        }
    }

    protected function handleForfeit($userId, $session)
    {
        $username = $session['username'];
        $totalAmount = $this->getSessionBetTotal($session);

        if (!empty($session['bets'])) {
            foreach ($session['bets'] as $bet) {
                GameHistory::create([
                    'telegram_id' => $userId,
                    'username' => $username,
                    'bet_type' => $this->getBetTypeDisplay($bet['bet_data']),
                    'bet_amount' => $bet['bet_amount'],
                    'win_amount' => 0,
                    'profit' => -$bet['bet_amount'],
                    'result_type' => 'Forfeit',
                    'rolls' => json_encode($session['rolls']),
                ]);
            }
        } else {
            GameHistory::create([
                'telegram_id' => $userId,
                'username' => $username,
                'bet_type' => $this->getSessionGameName($session),
                'bet_amount' => $totalAmount,
                'win_amount' => 0,
                'profit' => -$totalAmount,
                'result_type' => 'Forfeit',
                'rolls' => json_encode($session['rolls'] ?? []),
            ]);
        }
        
        $chatId = $session['chat_id'] ?? null;
        
        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);
        
        if ($chatId) {
             $msg = "⏳ <b>超时判负</b> ⏳\n" .
                    "━━━━━━━━━━━━━━━━━━\n" .
                    "👤 玩家: @{$username}\n" .
                    "🎲 进度: " . count($session['rolls']) . "/3 (未完成)\n" .
                    "📉 结果: <b>弃权 (扣除 {$totalAmount})</b>\n" .
                    "━━━━━━━━━━━━━━━━━━\n" .
                    "⚠️ 请在下注后 3分钟内 完成投掷！";
             $this->sendMessage($chatId, $msg, true, 'HTML');
        }
    }

    protected function processUpdates()
    {
        $response = $this->telegramHttp()->get("{$this->apiUrl}{$this->botToken}/getUpdates", [
            'offset' => $this->updateOffset,
            'timeout' => 10, 
            'allowed_updates' => ['message', 'callback_query'] 
        ]);

        if ($response->successful()) {
            $updates = $response->json('result');
            foreach ($updates as $update) {
                $this->updateOffset = $update['update_id'] + 1;
                
                if (isset($update['message'])) {
                    $this->handleMessage($update['message']);
                }
                
                // Handle Button Clicks
                if (isset($update['callback_query'])) {
                    $this->handleCallback($update['callback_query']);
                }
            }
        }
    }

    protected function handleMessage($message)
    {
        $chatId = $message['chat']['id'];
        $fromId = $message['from']['id'];
        $username = $message['from']['username'] ?? $message['from']['first_name'];
        $messageId = $message['message_id'];
        
        if (isset($message['dice']) && $message['dice']['emoji'] === '🎲') {
            $this->handleUserDice($chatId, $fromId, $username, $message['dice']['value']);
            return;
        }

        if (!isset($message['text'])) return;
        $text = trim($message['text']);

        if (preg_match('/^\/(start|help)(?:@\w+)?$/iu', $text)) {
            $this->sendMessage($chatId, "🎲 <b>欢迎使用 3Bot</b>\n\n发送 /menu 查看功能按钮。\n经典玩法示例：大 30\n三公：公 30\n筒子：推 30\n牛牛：牛 30", true, 'HTML');
            $this->sendMenu($chatId);
            return;
        }

        // Admin
        if ($this->isAdmin($fromId)) {
            if (str_starts_with($text, '/start_game')) {
                $this->isRunning = true;
                $this->sendMessage($chatId, "✅ 游戏服务已启动！\n玩法：先下注 (如 '大 100')，然后发送 3 个骰子表情。");
                return;
            }
            if (str_starts_with($text, '/stop_game')) {
                $this->isRunning = false;
                $this->sendMessage($chatId, "🛑 游戏服务已暂停。");
                return;
            }
            // 上分 (Charge) / 下分 (Deduct)
            // Support: "上分...", "@user 100", "100 @user", or Reply "-100"
            $isChargeCommand = str_contains($text, '上分') || str_contains($text, 'add');
            $hasMentionAndNum = str_contains($text, '@') && preg_match('/\d+/', $text);
            $isReplyNum = isset($message['reply_to_message']) && preg_match('/^[+-]?\d+$/', $text);

            if ($isChargeCommand || $hasMentionAndNum || $isReplyNum) {
                $this->handleAdminCharge($chatId, $text, $message);
                return;
            }
        }
        
        // Menu Command
        if ($text === '/menu' || $text === '菜单') {
            $this->sendMenu($chatId);
            return;
        }

        if ($text === '1') {
            $this->handleTextStats($chatId, $fromId, $messageId);
            return;
        }
        
        // --- 充值 / 余额 / 历史 ---
        if (str_starts_with($text, '/recharge') || $text === '充值') {
            $this->handleRecharge($chatId, $fromId, $username);
            return;
        }
        
        if (str_starts_with($text, '/balance') || $text === '余额' || $text === '查') {
            $this->handleBalance($chatId, $fromId, $username);
            return;
        }

        if (str_starts_with($text, '/history') || $text === '历史') {
            $this->handleHistory($chatId, $fromId, $username);
            return;
        }

        if (preg_match('/^\/cancel(?:@\w+)?$/iu', $text) || $text === '取消下注') {
            $this->handleCancelBet($fromId, $chatId);
            return;
        }
        // -----------------------

        // Betting Commands
        $this->handleBettingCommands($chatId, $fromId, $username, $text);
    }
    
    protected function handleCallback($callback)
    {
        $id = $callback['id'] ?? null;
        $fromId = $callback['from']['id'] ?? null;
        $data = $callback['data'] ?? '';
        $chatId = $callback['message']['chat']['id'] ?? null;

        if (!$id || !$fromId || !$chatId) {
            Log::warning('Telegram callback is missing required fields.', [
                'callback_data' => $data,
                'has_id' => (bool) $id,
                'has_user' => (bool) $fromId,
                'has_chat' => (bool) $chatId,
            ]);
            return;
        }

        Log::info('Telegram callback received.', [
            'callback_data' => $data,
            'telegram_id' => $fromId,
            'chat_id' => $chatId,
        ]);
        
        switch ($data) {
            case 'cancel_bet':
                $this->handleCancelBet($fromId, $chatId, $id);
                break;
            case 'check_bet':
                $this->handleCheckBet($fromId, $chatId, $id);
                break;
            case 'my_stats':
                $this->handleMyStats($fromId, $chatId, $id);
                break;
            default:
                $this->answerCallback($id, "该按钮暂不可用，请重新发送 /menu。", true);
                $this->sendMessage($chatId, "⚠️ 菜单按钮已过期，请发送 /menu 获取新菜单。");
                break;
        }
    }

    protected function handleCancelBet($userId, $chatId, $callbackId = null)
    {
        if (!isset($this->userSessions[$userId])) {
            if ($callbackId) {
                $this->answerCallback($callbackId, "您当前没有下注。", true);
            }
            $this->sendMessage($chatId, "ℹ️ 您当前没有可取消的下注。\n\n先发送下注指令，例如：大 30");
            return;
        }
        
        $session = $this->userSessions[$userId];
        if (!empty($session['rolls'])) {
            if ($callbackId) {
                $this->answerCallback($callbackId, "🚫 已开始摇骰子，无法取消！", true);
            }
            $this->sendMessage($chatId, "🚫 已经开始摇骰子，本局下注不能取消。");
            return;
        }
        
        $totalAmount = $this->getSessionBetTotal($session);
        if ($totalAmount <= 0) {
            Log::error('Unable to determine refundable bet amount.', [
                'telegram_id' => $userId,
                'session_keys' => array_keys($session),
            ]);
            if ($callbackId) {
                $this->answerCallback($callbackId, "退款金额异常，请联系管理员。", true);
            }
            $this->sendMessage($chatId, "⚠️ 无法确认本局冻结金额，下注尚未取消，请联系管理员处理。");
            return;
        }

        try {
            $newBalance = DB::transaction(function () use ($userId, $totalAmount) {
                $user = TelegramUser::where('telegram_id', $userId)->lockForUpdate()->first();
                if (!$user) {
                    throw new \RuntimeException('Telegram user not found for refund.');
                }

                $user->increment('balance', $totalAmount);
                return (float) $user->fresh()->balance;
            });
        } catch (\Throwable $exception) {
            Log::error('Bet cancellation refund failed.', [
                'telegram_id' => $userId,
                'amount' => $totalAmount,
                'error' => $exception->getMessage(),
            ]);
            if ($callbackId) {
                $this->answerCallback($callbackId, "退款失败，请稍后重试。", true);
            }
            $this->sendMessage($chatId, "⚠️ 本局暂未取消，退款写入失败，请稍后再次点击取消。");
            return;
        }

        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);
        if ($callbackId) {
            $this->answerCallback($callbackId, "✅ 下注已取消，本金退还。");
        }
        $this->sendMessage(
            $chatId,
            "✅ @{$session['username']} 已取消下注。\n💰 本局退回：{$totalAmount} 积分\n💳 当前余额：{$newBalance}"
        );

        Log::info('Bet cancelled and refunded.', [
            'telegram_id' => $userId,
            'amount' => $totalAmount,
            'balance' => $newBalance,
            'game_type' => $session['game_type'] ?? 'classic',
        ]);
    }

    protected function handleCheckBet($userId, $chatId, $callbackId)
    {
        if (!isset($this->userSessions[$userId])) {
            $this->answerCallback($callbackId, "您当前没有下注。", true);
            return;
        }
        
        $session = $this->userSessions[$userId];
        $rollsCount = count($session['rolls'] ?? []);
        $betSummary = $this->getSessionBetSummary($session);
        $totalAmount = $this->getSessionBetTotal($session);
        $requiredRolls = $this->getSessionRequiredRolls($session);

        $msg = "📝 <b>当前注单</b>\n" .
               "━━━━━━━━━━\n" .
               "{$betSummary}\n" .
               "💰 总额: <b>{$totalAmount}</b>\n" .
               "🎲 进度: {$rollsCount}/{$requiredRolls}";
        
        $this->answerCallback($callbackId, $msg, true);
    }

    protected function handleMyStats($userId, $chatId, $callbackId)
    {
        $today = Carbon::today();
        
        $stats = GameHistory::where('telegram_id', $userId)
            ->whereDate('created_at', $today)
            ->selectRaw('SUM(bet_amount) as total_flow, SUM(profit) as total_profit')
            ->first();

        $flow = $stats->total_flow ?? 0;
        $profit = $stats->total_profit ?? 0;
        
        // Get user balance for completeness
        $user = TelegramUser::where('telegram_id', $userId)->first();
        $balance = $user ? $user->balance : 0;
        
        $profitText = $profit >= 0 ? "+{$profit}" : "{$profit}";
        
        $msg = "📊 今日个人统计\n" .
               "━━━━━━━━━━━━━━\n" .
               "💸 流水总计: {$flow}\n" .
               "📈 今日盈亏: {$profitText}\n" .
               "💰 当前余额: {$balance}";
               
        $this->answerCallback($callbackId, $msg, true);
    }

    protected function handleTextStats($chatId, $userId, $replyMsgId = null)
    {
        $today = Carbon::today();
        
        $stats = GameHistory::where('telegram_id', $userId)
            ->whereDate('created_at', $today)
            ->selectRaw('SUM(bet_amount) as total_flow, SUM(profit) as total_profit')
            ->first();

        $flow = $stats->total_flow ?? 0;
        $profit = $stats->total_profit ?? 0;
        
        $user = TelegramUser::where('telegram_id', $userId)->first();
        $balance = $user ? $user->balance : 0;
        
        $profitText = $profit >= 0 ? "+{$profit}" : "{$profit}";
        
        $msg = "📊 <b>今日个人统计</b>\n" .
               "━━━━━━━━━━━━━━\n" .
               "💸 流水总计: <b>{$flow}</b>\n" .
               "📈 今日盈亏: <b>{$profitText}</b>\n" .
               "💰 当前余额: <b>{$balance}</b>";
               
        $this->sendMessage($chatId, $msg, $replyMsgId, 'HTML');
    }

    protected function getSessionBetTotal(array $session): float
    {
        if (isset($session['reserved_amount'])) {
            return (float) $session['reserved_amount'];
        }

        if (isset($session['bet_amount'])) {
            return (float) $session['bet_amount'];
        }

        return array_reduce(
            $session['bets'] ?? [],
            fn (float $total, array $bet) => $total + (float) ($bet['bet_amount'] ?? 0),
            0.0
        );
    }

    protected function getSessionGameName(array $session): string
    {
        return match ($session['game_type'] ?? 'classic') {
            'san_gong', 'san_gong_player_first' => '三公',
            'tongzi' => '筒子',
            'niuniu' => '牛牛',
            default => '经典玩法',
        };
    }

    protected function getSessionRequiredRolls(array $session): int
    {
        return match ($session['game_type'] ?? 'classic') {
            'tongzi' => 2,
            'niuniu' => 5,
            default => 3,
        };
    }

    protected function getSessionBetSummary(array $session): string
    {
        if (!empty($session['bets'])) {
            return $this->formatBetSummary($session['bets']);
        }

        $amount = $this->getSessionBetTotal($session);
        return $this->getSessionGameName($session) . ": <b>{$amount}</b>";
    }

    protected function persistUserSession($userId): void
    {
        if (!isset($this->userSessions[$userId])) {
            return;
        }

        $session = $this->userSessions[$userId];
        TelegramGameSession::updateOrCreate(
            ['telegram_id' => $userId],
            [
                'chat_id' => $session['chat_id'] ?? $userId,
                'username' => $session['username'] ?? null,
                'reserved_amount' => $this->getSessionBetTotal($session),
                'session_data' => $session,
            ]
        );
    }

    protected function deletePersistedSession($userId): void
    {
        TelegramGameSession::where('telegram_id', $userId)->delete();
    }

    protected function loadPersistedSessions(): void
    {
        foreach (TelegramGameSession::all() as $record) {
            $session = $record->session_data;
            if (!is_array($session)) {
                continue;
            }

            $session['chat_id'] ??= $record->chat_id;
            $session['username'] ??= $record->username;
            $session['reserved_amount'] ??= (float) $record->reserved_amount;
            $this->userSessions[(int) $record->telegram_id] = $session;
        }

        if (!empty($this->userSessions)) {
            $this->info('Restored ' . count($this->userSessions) . ' unfinished game session(s).');
        }
    }

    protected function sendMenu($chatId)
    {
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '❌ 取消下注', 'callback_data' => 'cancel_bet'],
                    ['text' => '🔍 查看下注', 'callback_data' => 'check_bet'],
                ],
                [
                    ['text' => '📊 今日统计', 'callback_data' => 'my_stats'],
                ]
            ]
        ];
        $this->sendMessage($chatId, "🛠 <b>功能菜单</b>", false, 'HTML', $keyboard);
    }

    protected function handleHistory($chatId, $userId, $username)
    {
        $records = GameHistory::where('telegram_id', $userId)
            ->latest()
            ->take(10)
            ->get();

        if ($records->isEmpty()) {
            $this->sendMessage($chatId, "📭 暂无游戏记录。", true);
            return;
        }

        $msg = "📜 <b>最近 10 局游戏记录 (User: $username)</b>\n\n";
        foreach ($records as $record) {
            $profit = $record->profit > 0 ? "+{$record->profit}" : $record->profit;
            $msg .= "⏱ {$record->created_at->format('m-d H:i:s')}\n";
            $msg .= "🎲 玩法: {$record->bet_type} | 结果: {$record->result_type} ({$record->rolls})\n";
            $msg .= "💰 盈亏: <b>{$profit}</b>\n";
            $msg .= "------------------------\n";
        }

        $this->sendMessage($chatId, $msg, true, 'HTML');
    }

    protected function handleBalance($chatId, $userId, $username)
    {
        $user = TelegramUser::where('telegram_id', $userId)->first();
        if (!$user) {
            $this->sendMessage($chatId, "👤 用户未注册。", true);
            return;
        }

        $msg = "💳 <b>用户余额查询</b>\n\n";
        $msg .= "👤 用户: {$username}\n";
        $msg .= "💰 余额: <b>{$user->balance}</b>\n";
        
        if ($user->wallet_address) {
             $msg .= "👛 钱包地址 (TRC20):\n<code>{$user->wallet_address}</code>\n";
        }

        $this->sendMessage($chatId, $msg, true, 'HTML');
    }

    protected function handleRecharge($chatId, $userId, $username)
    {
        $user = TelegramUser::firstOrCreate(
            ['telegram_id' => $userId],
            ['username' => $username]
        );

        if (!$user->wallet_address) {
            // Generate Wallet
            try {
                $walletService = new \App\Services\WalletService();
                $wallet = $walletService->generateWallet();
                
                $user->wallet_address = $wallet['address'];
                $user->wallet_private_key = $walletService->encryptPrivateKey($wallet['privateKey']);
                $user->save();
            } catch (\Exception $e) {
                Log::error("Wallet generation failed: " . $e->getMessage());
                $this->sendMessage($chatId, "❌ 钱包生成失败，请稍后重试。", true);
                return;
            }
        }

        $msg = "💎 <b>充值中心 (TRC20)</b>\n\n";
        $msg .= "请向以下 TRON 地址转账 (USDT/TRX):\n\n";
        $msg .= "<code>{$user->wallet_address}</code>\n\n";
        $msg .= "⚠️ <b>注意：</b>\n";
        $msg .= "1. 仅支持 TRC20 网络。\n";
        $msg .= "2. 转账后自动到账 (需等待网络确认)。\n";
        $msg .= "3. 最小充值金额: 1 USDT / 10 TRX。\n";
        // $msg .= "4. 发送 /check 检查到账状态 (暂未开放)。";

        // Generate QR Code URL (using a public API or local generator if available, for now just text)
        // $qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . $user->wallet_address;
        
        $this->sendMessage($chatId, $msg, true, 'HTML');
    }

    protected function handleBettingCommands($chatId, $fromId, $username, $text)
    {
        $bets = [];
        $totalAmount = 0;
        $isModify = false;

        // Check for "改" at the end of the string to indicate modification
        if (preg_match('/\s+改$/u', $text)) {
            $isModify = true;
            $text = preg_replace('/\s+改$/u', '', $text); // Remove "改" for parsing
        }

        // --- SanGong Command Check ---
        if (preg_match('/^(?:公|gong)\s*(\d+)$/iu', $text, $match)) {
            $amount = (int)$match[1];
            $playerRollsFirst = true; // Always player rolls first for SanGong
            
            if ($amount < 30 || $amount <= 0) {
                $this->sendMessage($chatId, "⚠️ 下注金额最低为 30！", true);
                return;
            }
            
            $user = TelegramUser::firstOrCreate(
                ['telegram_id' => $fromId],
                ['username' => $username, 'balance' => 0]
            );
            
            if (isset($this->userSessions[$fromId])) {
                $this->sendMessage($chatId, "✋ 您有一局未完成的游戏！", true);
                return;
            }

            if ($user->balance < $amount) {
                $this->sendMessage($chatId, "💸 余额不足！", true);
                return;
            }

            $user->balance -= $amount;
            $user->save();

            $gameType = 'san_gong_player_first'; // Always player rolls first

            $this->userSessions[$fromId] = [
                'game_type' => $gameType,
                'bet_amount' => $amount,
                'reserved_amount' => $amount,
                'rolls' => [],
                'username' => $username,
                'start_time' => time(),
                'chat_id' => $chatId,
                'first_roll_time' => null,
                'player_rolls_first' => $playerRollsFirst,
                'banker_rolls' => [], // To store banker's dice later
            ];
            $this->persistUserSession($fromId);

            $this->sendMessage($chatId, "🎲 <b>下注成功 (三公 - 玩家先摇)</b>\n请发送 3 个骰子 (🎲)！", true, 'HTML');
            return;
        }
        // ---------------------------

        // --- Tongzi Command Check ---
        if (preg_match('/^(?:推|tui)\s*(\d+)$/iu', $text, $match)) {
            $amount = (int)$match[1];
            
            if ($amount < 30 || $amount <= 0) {
                $this->sendMessage($chatId, "⚠️ 下注金额最低为 30！", true);
                return;
            }
            
            $user = TelegramUser::firstOrCreate(
                ['telegram_id' => $fromId],
                ['username' => $username, 'balance' => 0]
            );
            
            if (isset($this->userSessions[$fromId])) {
                $this->sendMessage($chatId, "✋ 您有一局未完成的游戏！", true);
                return;
            }

            if ($user->balance < $amount) {
                $this->sendMessage($chatId, "💸 余额不足！", true);
                return;
            }

            $user->balance -= $amount;
            $user->save();

            $this->userSessions[$fromId] = [
                'game_type' => 'tongzi',
                'bet_amount' => $amount,
                'reserved_amount' => $amount,
                'rolls' => [], // Player's rolls
                'username' => $username,
                'start_time' => time(),
                'chat_id' => $chatId,
                'first_roll_time' => null,
                'banker_rolls' => [], // Bot's rolls (dealer) - now rolled in settleTongziGame
            ];
            $this->persistUserSession($fromId);

            $this->sendMessage($chatId, "🎲 <b>下注成功 (筒子 - 玩家先摇)</b>\n请发送 2 个骰子 (🎲)！", true, 'HTML');
            return;
        }
        // ---------------------------

        // --- NiuNiu Command Check ---
        if (preg_match('/^(?:牛|niu)\s*(\d+)$/iu', $text, $match)) {
            $amount = (int)$match[1];
            
            if ($amount < 30 || $amount <= 0) {
                $this->sendMessage($chatId, "⚠️ 下注金额最低为 30！", true);
                return;
            }
            
            $user = TelegramUser::firstOrCreate(
                ['telegram_id' => $fromId],
                ['username' => $username, 'balance' => 0]
            );
            
            if (isset($this->userSessions[$fromId])) {
                $this->sendMessage($chatId, "✋ 您有一局未完成的游戏！", true);
                return;
            }

            if ($user->balance < $amount) {
                $this->sendMessage($chatId, "💸 余额不足！", true);
                return;
            }

            $user->balance -= $amount;
            $user->save();

            $this->userSessions[$fromId] = [
                'game_type' => 'niuniu',
                'bet_amount' => $amount,
                'reserved_amount' => $amount,
                'rolls' => [],
                'username' => $username,
                'start_time' => time(),
                'chat_id' => $chatId,
                'first_roll_time' => null,
            ];
            $this->persistUserSession($fromId);

            $this->sendMessage($chatId, "🎲 <b>下注成功 (牛牛)</b>\n请发送 5 个骰子 (🎲)！", true, 'HTML');
            return;
        }
        // ---------------------------

        // Regex to capture all supported bet types
        // 1. Compound: (大单|小双|大双|小单) + Amount
        // 2. Point Kill Leopard: (\d+豹子) + Amount
        // 3. Point Kill: (\d+杀) + Amount
        // 4. Dragon/Tiger: (龙|虎|合) + Amount
        // 5. Special: (对子|豹子|顺子|123顺子) + Amount
        // 6. Single: (大|小|单|双|Big|Small|Odd|Even) + Amount
        
        $pattern = '/(大单|小双|大双|小单|\d+豹子|\d+杀|龙|虎|合|对子|豹子|顺子|123顺子|大|小|单|双|Big|Small|Odd|Even)\s*(\d+)/iu';

        if (preg_match_all($pattern, $text, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $typeRaw = $match[1];
                $amount = (int)$match[2];
                
                if ($amount < 30 || $amount <= 0) {
                    $this->sendMessage($chatId, "⚠️ 下注金额最低为 30！({$typeRaw})", true);
                    return;
                }

                $betTypeData = $this->parseBetType($typeRaw);
                if ($betTypeData) {
                    $bets[] = [
                        'bet_data' => $betTypeData,
                        'bet_amount' => $amount
                    ];
                    $totalAmount += $amount;
                }
            }
        }

        if (empty($bets)) {
            return; // No valid bets found
        }

        $user = TelegramUser::firstOrCreate(
            ['telegram_id' => $fromId],
            ['username' => $username, 'balance' => 0]
        );

        $currentSession = $this->userSessions[$fromId] ?? null;

        if ($isModify) {
            if (!$currentSession) {
                $this->sendMessage($chatId, "⚠️ 您当前没有下注，无法修改。请直接下注。", true);
                return;
            }
            if (count($currentSession['rolls']) > 0) {
                $this->sendMessage($chatId, "🚫 已经开始摇骰子了，无法改注！", true);
                return;
            }
            
            // Calculate difference: New Total - Old Total
            // Old total is sum of all previous bets
            $oldTotal = 0;
            foreach ($currentSession['bets'] as $b) {
                $oldTotal += $b['bet_amount'];
            }

            $diff = $totalAmount - $oldTotal;
            if ($user->balance < $diff) {
                $this->sendMessage($chatId, "💸 余额不足！", true);
                return;
            }

            $user->balance -= $diff;
            $user->save();

            // Replace bets
            $this->userSessions[$fromId]['bets'] = $bets;
            $this->userSessions[$fromId]['reserved_amount'] = $totalAmount;
            $this->persistUserSession($fromId);
            
            $betSummary = $this->formatBetSummary($bets);
            $this->sendMessage($chatId, "✅ 改注成功:\n{$betSummary}", true);
            return;
        }

        if ($currentSession) {
            $this->sendMessage($chatId, "✋ 您有一局未完成的游戏！", true);
            return;
        }

        if ($user->balance < $totalAmount) {
            $this->sendMessage($chatId, "💸 余额不足！", true);
            return;
        }

        $user->balance -= $totalAmount;
        $user->save();

        $this->userSessions[$fromId] = [
            'bets' => $bets,
            'reserved_amount' => $totalAmount,
            'rolls' => [],
            'username' => $username,
            'start_time' => time(),
            'chat_id' => $chatId,
            'first_roll_time' => null
        ];
        $this->persistUserSession($fromId);

        // Send confirmation with buttons
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '❌ 取消下注', 'callback_data' => 'cancel_bet'],
                    ['text' => '🔍 查看下注', 'callback_data' => 'check_bet'],
                    ['text' => '📊 统计', 'callback_data' => 'my_stats'],
                ]
            ]
        ];
        
        $betSummary = $this->formatBetSummary($bets);

        $msg = "🎲 <b>下注成功</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👤 玩家: @{$username}\n" .
               "{$betSummary}\n" .
               "💰 总额: <b>{$totalAmount}</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👇 请发送 3 个骰子 (🎲) 开奖";

        $this->sendMessage($chatId, $msg, true, 'HTML', $keyboard);
    }

    protected function parseBetType($typeRaw)
    {
        // Compound
        if (preg_match('/^(大单|小双|大双|小单)$/iu', $typeRaw)) {
             switch ($typeRaw) {
                case '大单': return ['type' => 'compound', 'sub_type' => 'big_odd'];
                case '小双': return ['type' => 'compound', 'sub_type' => 'small_even'];
                case '大双': return ['type' => 'compound', 'sub_type' => 'big_even'];
                case '小单': return ['type' => 'compound', 'sub_type' => 'small_odd'];
            }
        }
        // Point Kill Leopard
        if (preg_match('/^(\d+)豹子$/iu', $typeRaw, $m)) {
            $betPoint = (int)$m[1];
            if ($betPoint >= 1 && $betPoint <= 6) {
                return ['type' => 'point_kill_leopard', 'point' => $betPoint];
            }
        }
        // Point Kill
        if (preg_match('/^(\d+)杀$/iu', $typeRaw, $m)) {
            $sum = (int)$m[1];
            if ($sum >= 4 && $sum <= 17) {
                return ['type' => 'point_kill', 'sum' => $sum];
            }
        }
        // Dragon Tiger
        if (preg_match('/^(龙|虎|合)$/iu', $typeRaw)) {
             switch ($typeRaw) {
                case '龙': return ['type' => 'dragon_tiger', 'sub_type' => 'dragon'];
                case '虎': return ['type' => 'dragon_tiger', 'sub_type' => 'tiger'];
                case '合': return ['type' => 'dragon_tiger', 'sub_type' => 'tie'];
            }
        }
        // Special
        if (preg_match('/^(对子|豹子|顺子|123顺子)$/iu', $typeRaw)) {
            switch ($typeRaw) {
                case '对子': return ['type' => 'special', 'sub_type' => 'pairs'];
                case '豹子': return ['type' => 'special', 'sub_type' => 'leopard'];
                case '顺子': return ['type' => 'special', 'sub_type' => 'straight'];
                case '123顺子': return ['type' => 'special', 'sub_type' => 'straight_123'];
            }
        }
        // Single
        if (preg_match('/^(大|小|单|双|Big|Small|Odd|Even)$/iu', $typeRaw)) {
             switch (strtolower($typeRaw)) {
                case '大': case 'big': return ['type' => 'single', 'sub_type' => 'big'];
                case '小': case 'small': return ['type' => 'single', 'sub_type' => 'small'];
                case '单': case 'odd': return ['type' => 'single', 'sub_type' => 'odd'];
                case '双': case 'even': return ['type' => 'single', 'sub_type' => 'even'];
            }
        }
        return null;
    }

    protected function formatBetSummary($bets)
    {
        $lines = [];
        foreach ($bets as $bet) {
            $name = $this->getBetTypeDisplay($bet['bet_data']);
            $oddsKey = $this->getBetOddsKey($bet['bet_data']);
            $odds = isset($this->odds[$oddsKey]) ? $this->odds[$oddsKey] : 'N/A';

            $lines[] = "🎯 {$name} (赔率: {$odds}x): <b>{$bet['bet_amount']}</b>";
        }
        return implode("\n", $lines);
    }

    protected function getBetOddsKey($betData)
    {
        switch ($betData['type']) {
            case 'single':
                return match($betData['sub_type']) {
                    'big', 'small' => 'single_big_small',
                    'odd', 'even' => 'single_odd_even',
                };
            case 'compound':
                return match($betData['sub_type']) {
                    'big_odd' => 'compound_big_odd',
                    'small_even' => 'compound_small_even',
                    'big_even' => 'compound_big_even',
                    'small_odd' => 'compound_small_odd',
                };
            case 'special':
                return match($betData['sub_type']) {
                    'pairs' => 'special_pairs',
                    'leopard' => 'special_leopard',
                    'straight' => 'special_straight',
                    'straight_123' => 'special_straight_123',
                };
            case 'point_kill':
                return "point_kill_sum_{$betData['sum']}";
            case 'point_kill_leopard':
                return 'point_kill_leopard';
            case 'dragon_tiger':
                return match($betData['sub_type']) {
                    'dragon', 'tiger' => 'dragon_tiger_dragon_tiger',
                    'tie' => 'dragon_tiger_tie',
                };
            default:
                return ''; // Should not happen with valid bet_data
        }
    }

    // Helper function to get display text for bet type
    protected function getBetTypeDisplay($betTypeData) {
        switch ($betTypeData['type']) {
            case 'single':
                return match($betTypeData['sub_type']) {
                    'big' => '大', 'small' => '小', 'odd' => '单', 'even' => '双',
                };
            case 'compound':
                return match($betTypeData['sub_type']) {
                    'big_odd' => '大单', 'small_even' => '小双', 'big_even' => '大双', 'small_odd' => '小单',
                };
            case 'special':
                return match($betTypeData['sub_type']) {
                    'pairs' => '对子', 'leopard' => '豹子', 'straight' => '顺子', 'straight_123' => '123顺子',
                };
            case 'point_kill':
                return "{$betTypeData['sum']}杀";
            case 'point_kill_leopard':
                return "{$betTypeData['point']}豹子";
            case 'dragon_tiger':
                return match($betTypeData['sub_type']) {
                    'dragon' => '龙', 'tiger' => '虎', 'tie' => '合',
                };
            default:
                return '未知类型';
        }
    }

    protected function handleUserDice($chatId, $userId, $username, $diceValue)
    {
        if (!isset($this->userSessions[$userId])) {
            return;
        }

        // --- SanGong Hand Roll Logic ---
        if (isset($this->userSessions[$userId]['game_type']) && (
            $this->userSessions[$userId]['game_type'] === 'san_gong' || 
            $this->userSessions[$userId]['game_type'] === 'san_gong_player_first'
        )) {
            $this->userSessions[$userId]['rolls'][] = $diceValue;
            $count = count($this->userSessions[$userId]['rolls']);

            if ($count === 1) {
                $this->userSessions[$userId]['first_roll_time'] = time();
            }

            if ($count === 3) {
                $this->settleSanGongGame($chatId, $userId);
            } else {
                $this->persistUserSession($userId);
            }
            return;
        }
        // -----------------------------
        
        // --- Tongzi Hand Roll Logic ---
        if (isset($this->userSessions[$userId]['game_type']) && $this->userSessions[$userId]['game_type'] === 'tongzi') {
            $this->userSessions[$userId]['rolls'][] = $diceValue;
            $count = count($this->userSessions[$userId]['rolls']);

            if ($count === 1) {
                $this->userSessions[$userId]['first_roll_time'] = time();
            }

            if ($count === 2) { // Tongzi uses 2 dice
                $this->settleTongziGame($chatId, $userId);
            } else {
                $this->persistUserSession($userId);
            }
            return;
        }
        // -----------------------------

        // --- NiuNiu Hand Roll Logic ---
        if (isset($this->userSessions[$userId]['game_type']) && $this->userSessions[$userId]['game_type'] === 'niuniu') {
            $this->userSessions[$userId]['rolls'][] = $diceValue;
            $count = count($this->userSessions[$userId]['rolls']);

            if ($count === 1) {
                $this->userSessions[$userId]['first_roll_time'] = time();
            }

            if ($count === 5) {
                $this->settleNiuNiuGame($chatId, $userId, $this->userSessions[$userId]['rolls'], true);
            } else {
                $this->persistUserSession($userId);
            }
            return;
        }
        // -----------------------------

        $this->userSessions[$userId]['rolls'][] = $diceValue;
        $count = count($this->userSessions[$userId]['rolls']);

        if ($count === 1) {
            $this->userSessions[$userId]['first_roll_time'] = time();
        }

        if ($count < 3) {
            $this->persistUserSession($userId);
        } else {
            $this->settleGame($chatId, $userId);
        }
    }

    protected function settleNiuNiuGame($chatId, $userId, $userDice, $visualizeBanker = false)
    {
        $session = $this->userSessions[$userId];
        $betAmount = $session['bet_amount'];
        $username = $session['username'];
        
        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);
        
        // Banker Rolls
        $bankerDice = [];
        if ($visualizeBanker) {
            for ($i = 0; $i < 5; $i++) {
                $bankerDice[] = $this->sendDice($chatId);
                usleep(500000); // 0.5s delay
            }
        } else {
            for ($i = 0; $i < 5; $i++) $bankerDice[] = rand(1, 6);
        }
        
        // Calculate Results
        $pRes = $this->calculateNiuResult($userDice);
        $bRes = $this->calculateNiuResult($bankerDice);
        
        // Compare
        // Rules: Same points Banker wins.
        $playerWins = false;
        if ($pRes['rank'] > $bRes['rank']) {
            $playerWins = true;
        } elseif ($pRes['rank'] < $bRes['rank']) {
            $playerWins = false;
        } else {
            // Ranks equal -> Banker wins
            $playerWins = false;
        }
        
        $winnerRes = $playerWins ? $pRes : $bRes;
        $multiplier = $winnerRes['mul'];
        
        $user = TelegramUser::where('telegram_id', $userId)->first();
        $balance = $user->balance; // Balance AFTER deducting betAmount
        
        // Effective Balance (Equity) = CurrentBalance + BetAmount
        $equity = $balance + $betAmount;
        
        $profit = 0;
        $resultTitle = "";
        $profitText = "";

        if ($playerWins) {
            // Win: Bet * Multiplier
            $winAmount = $betAmount * $multiplier;
            
            // Cap Win at Equity (Balance)
            if ($winAmount > $equity) {
                $winAmount = $equity;
            }
            
            $profit = $winAmount;
            $payout = $betAmount + $profit; // Refund bet + profit
            
            $user->balance += $payout;
            $user->save();
            
            $resultTitle = "🏆 <b>玩家胜利!</b>";
            $profitText = "+{$profit}";
            
        } else {
            // Lose: Bet * Multiplier
            // Player already paid BetAmount.
            // Extra Loss = (Bet * Multiplier) - BetAmount
            $totalLoss = $betAmount * $multiplier;
            
            // Cap Loss at Equity
            if ($totalLoss > $equity) {
                $totalLoss = $equity;
            }
            
            $extraLoss = $totalLoss - $betAmount;
            if ($extraLoss > 0) {
                 $user->balance -= $extraLoss;
                 $user->save();
            }
            
            $profit = -$totalLoss;
            $resultTitle = "💀 <b>庄家胜利!</b>";
            $profitText = "{$profit}";
        }
        
        // Logging
        GameHistory::create([
            'telegram_id' => $userId,
            'username' => $username,
            'bet_type' => "牛牛 {$betAmount}",
            'bet_amount' => $betAmount, 
            'win_amount' => $playerWins ? ($betAmount + $profit) : 0,
            'profit' => $profit,
            'result_type' => $playerWins ? "赢 ({$pRes['name']} vs {$bRes['name']})" : "输 ({$bRes['name']} vs {$pRes['name']})",
            'rolls' => json_encode(['p' => $userDice, 'b' => $bankerDice]),
        ]);
        
        // Message
        $diceEmojis = [1 => '1️⃣', 2 => '2️⃣', 3 => '3️⃣', 4 => '4️⃣', 5 => '5️⃣', 6 => '6️⃣'];
        $pDiceStr = implode('', array_map(fn($v) => $diceEmojis[$v], $userDice));
        $bDiceStr = implode('', array_map(fn($v) => $diceEmojis[$v], $bankerDice));
        
        $msg = "🐮 <b>牛牛对决</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👤 玩家: @{$username}\n" .
               "🎲 闲家: {$pDiceStr} [{$pRes['name']}]\n" .
               "🎲 庄家: {$bDiceStr} [{$bRes['name']}]\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "{$resultTitle}\n" .
               "💰 结果: <b>{$profitText}</b> (倍率: {$multiplier}x)\n" .
               "💰 余额: <b>{$user->balance}</b>";

        $this->sendMessage($chatId, $msg, true, 'HTML');
    }

    protected function settleSanGongGame($chatId, $userId)
    {
        $session = $this->userSessions[$userId];
        $playerRolls = $session['rolls'];
        $betAmount = $session['bet_amount'];
        $username = $session['username'];
        $playerRollsFirst = $session['player_rolls_first'];

        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);

        $bankerRolls = $session['banker_rolls'] ?? [];
        
        // If player rolled first, bot needs to roll for banker
        if ($playerRollsFirst) {
            $this->sendMessage($chatId, "庄家摇骰中...", false, 'HTML');
            for ($i = 0; $i < 3; $i++) {
                $bankerRolls[] = $this->sendDice($chatId);
                usleep(500000); // 0.5s delay
            }
        }
        
        // Calculate results for both player and banker
        $playerHand = $this->calculateSanGongResult($playerRolls);
        $bankerHand = $this->calculateSanGongResult($bankerRolls);

        $playerWins = false;
        $resultText = '';

        // Determine winner
        if ($playerHand['rank'] > $bankerHand['rank']) {
            $playerWins = true;
        } elseif ($bankerHand['rank'] > $playerHand['rank']) {
            $playerWins = false;
        } else { // Ranks are equal, compare values
            if ($playerHand['value'] > $bankerHand['value']) {
                $playerWins = true;
            } elseif ($bankerHand['value'] > $playerHand['value']) {
                $playerWins = false;
            } else {
                // If ranks and values are equal, dealer wins (per game rules)
                $playerWins = false;
            }
        }

        // Use the winning hand's type to determine the multiplier
        $winningHandType = $playerWins ? $playerHand['type'] : $bankerHand['type'];
        $multiplier = $this->sanGongOdds[$winningHandType] ?? 1;

        $user = TelegramUser::where('telegram_id', $userId)->first();
        $balance = $user->balance; // Balance AFTER deducting betAmount
        $equity = $balance + $betAmount; // Effective Balance (Equity)

        $profit = 0;
        $resultTitle = "";
        $profitText = "";

        if ($playerWins) {
            $winAmount = $betAmount * $multiplier;
            if ($winAmount > $equity) {
                $winAmount = $equity;
            }
            $profit = $winAmount;
            $payout = $betAmount + $profit;
            
            $user->balance += $payout;
            $user->save();
            
            $resultTitle = "🏆 <b>玩家胜利!</b>";
            $profitText = "+{$profit}";
        } else {
            $totalLoss = $betAmount * $multiplier;
            if ($totalLoss > $equity) {
                $totalLoss = $equity;
            }
            $extraLoss = $totalLoss - $betAmount;
            if ($extraLoss > 0) {
                 $user->balance -= $extraLoss;
                 $user->save();
            }
            $profit = -$totalLoss;
            $resultTitle = "💀 <b>庄家胜利!</b>";
            $profitText = "{$profit}";
        }
        
        // Logging
        GameHistory::create([
            'telegram_id' => $userId,
            'username' => $username,
            'bet_type' => "三公 {$betAmount}",
            'bet_amount' => $betAmount, 
            'win_amount' => $playerWins ? ($betAmount + $profit) : 0,
            'profit' => $profit,
            'result_type' => $playerWins ? "赢 ({$playerHand['type']} vs {$bankerHand['type']})" : "输 ({$bankerHand['type']} vs {$playerHand['type']})",
            'rolls' => json_encode(['p' => $playerRolls, 'b' => $bankerRolls]),
        ]);
        
        // Message
        $diceEmojis = [1 => '1️⃣', 2 => '2️⃣', 3 => '3️⃣', 4 => '4️⃣', 5 => '5️⃣', 6 => '6️⃣'];
        $pDiceStr = implode(' ', array_map(fn($v) => $diceEmojis[$v], $playerRolls));
        $bDiceStr = implode(' ', array_map(fn($v) => $diceEmojis[$v], $bankerRolls));
        
        $msg = "🃏 <b>三公对决</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👤 玩家: @{$username}\n" .
               "🎲 闲家: {$pDiceStr} [{$playerHand['type']}]\n" .
               "🎲 庄家: {$bDiceStr} [{$bankerHand['type']}]\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "{$resultTitle}\n" .
               "💰 结果: <b>{$profitText}</b> (倍率: {$multiplier}x)\n" .
               "💰 余额: <b>{$user->balance}</b>";

        $this->sendMessage($chatId, $msg, true, 'HTML');
    }

    protected function settleTongziGame($chatId, $userId)
    {
        $session = $this->userSessions[$userId];
        $playerRolls = $session['rolls'];
        $betAmount = $session['bet_amount'];
        $username = $session['username'];
        // $bankerRolls = $session['banker_rolls']; // No longer pre-filled

        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);

        // Bot now rolls for banker inside settleTongziGame
        $this->sendMessage($chatId, "庄家摇骰中...", false, 'HTML');
        $bankerRolls = [];
        for ($i = 0; $i < 2; $i++) { // Tongzi uses 2 dice
            $bankerRolls[] = $this->sendDice($chatId);
            usleep(500000); // 0.5s delay
        }

        // Calculate results for both player and banker
        $playerHand = $this->calculateTongziResult($playerRolls);
        $bankerHand = $this->calculateTongziResult($bankerRolls);

        $playerWins = false;

        // Determine winner based on Tongzi rules
        // Prioritize Pairs
        if ($playerHand['type'] === '对子' && $bankerHand['type'] !== '对子') {
            $playerWins = true;
        } elseif ($playerHand['type'] !== '对子' && $bankerHand['type'] === '对子') {
            $playerWins = false;
        } elseif ($playerHand['type'] === '对子' && $bankerHand['type'] === '对子') {
            // Both are pairs
            if ($playerHand['pair_value'] > $bankerHand['pair_value']) {
                $playerWins = true;
            } elseif ($bankerHand['pair_value'] > $playerHand['pair_value']) {
                $playerWins = false;
            } else {
                // Pair values are equal (e.g., both 1-1). Dealer wins.
                // "对子杀点数同点庄赢" - if points (implied by same pair) are tied, dealer wins.
                $playerWins = false;
            }
        } else {
            // Both are 散牌 (non-pairs)
            if ($playerHand['points'] > $bankerHand['points']) {
                $playerWins = true;
            } elseif ($bankerHand['points'] > $playerHand['points']) {
                $playerWins = false;
            } else {
                // Points are equal. Dealer wins.
                $playerWins = false;
            }
        }

        $multiplier = $this->tongziOdds['normal_win'] ?? 1; // 1:1 payout

        $user = TelegramUser::where('telegram_id', $userId)->first();
        $balance = $user->balance; // Balance AFTER deducting betAmount
        $equity = $balance + $betAmount; // Effective Balance (Equity)

        $profit = 0;
        $resultTitle = "";
        $profitText = "";

        if ($playerWins) {
            $winAmount = $betAmount * $multiplier;
            if ($winAmount > $equity) {
                $winAmount = $equity;
            }
            $profit = $winAmount;
            $payout = $betAmount + $profit;
            
            $user->balance += $payout;
            $user->save();
            
            $resultTitle = "🏆 <b>玩家胜利!</b>";
            $profitText = "+{$profit}";
        } else {
            $totalLoss = $betAmount * $multiplier;
            if ($totalLoss > $equity) {
                $totalLoss = $equity;
            }
            $extraLoss = $totalLoss - $betAmount;
            if ($extraLoss > 0) {
                 $user->balance -= $extraLoss;
                 $user->save();
            }
            $profit = -$totalLoss;
            $resultTitle = "💀 <b>庄家胜利!</b>";
            $profitText = "{$profit}";
        }
        
        // Logging
        GameHistory::create([
            'telegram_id' => $userId,
            'username' => $username,
            'bet_type' => "筒子 {$betAmount}",
            'bet_amount' => $betAmount, 
            'win_amount' => $playerWins ? ($betAmount + $profit) : 0,
            'profit' => $profit,
            'result_type' => $playerWins ? "赢 ({$playerHand['type']}:{$playerHand['points']} vs {$bankerHand['type']}:{$bankerHand['points']})" : "输 ({$bankerHand['type']}:{$bankerHand['points']} vs {$playerHand['type']}:{$playerHand['points']})",
            'rolls' => json_encode(['p' => $playerRolls, 'b' => $bankerRolls]),
        ]);
        
        // Message
        $diceEmojis = [1 => '1️⃣', 2 => '2️⃣', 3 => '3️⃣', 4 => '4️⃣', 5 => '5️⃣', 6 => '6️⃣'];
        $pDiceStr = implode(' ', array_map(fn($v) => $diceEmojis[$v], $playerRolls));
        $bDiceStr = implode(' ', array_map(fn($v) => $diceEmojis[$v], $bankerRolls));
        
        $msg = "🀄 <b>筒子对决</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👤 玩家: @{$username}\n" .
               "🎲 闲家: {$pDiceStr} [{$playerHand['type']}" . ($playerHand['type'] === '对子' ? "({$playerHand['pair_value']})" : "") . " - {$playerHand['points']}点]\n" .
               "🎲 庄家: {$bDiceStr} [{$bankerHand['type']}" . ($bankerHand['type'] === '对子' ? "({$bankerHand['pair_value']})" : "") . " - {$bankerHand['points']}点]\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "{$resultTitle}\n" .
               "💰 结果: <b>{$profitText}</b> (倍率: {$multiplier}x)\n" .
               "💰 余额: <b>{$user->balance}</b>";

        $this->sendMessage($chatId, $msg, true, 'HTML');
    }


    protected function settleGame($chatId, $userId)
    {
        $session = $this->userSessions[$userId];
        $rolls = $session['rolls'];
        $bets = $session['bets'];
        $username = $session['username'];

        unset($this->userSessions[$userId]);
        $this->deletePersistedSession($userId);

        $sum = array_sum($rolls);
        
        // 1. Determine all winning attributes for this roll
        $winningAttributes = [];

        // Basic Attributes
        $isBig = ($sum >= 11 && $sum <= 17);
        $isSmall = ($sum >= 4 && $sum <= 10);
        $isOdd = ($sum % 2 != 0);
        $isEven = ($sum % 2 == 0);

        if ($isBig) $winningAttributes[] = '大';
        if ($isSmall) $winningAttributes[] = '小';
        if ($isOdd) $winningAttributes[] = '单';
        if ($isEven) $winningAttributes[] = '双';

        // Combinations
        if ($isBig && $isOdd) $winningAttributes[] = '大单';
        if ($isSmall && $isEven) $winningAttributes[] = '小双';
        if ($isBig && $isEven) $winningAttributes[] = '大双';
        if ($isSmall && $isOdd) $winningAttributes[] = '小单';

        // Special Patterns
        $sortedRolls = $rolls;
        sort($sortedRolls);
        $isLeopard = ($rolls[0] == $rolls[1] && $rolls[1] == $rolls[2]); 
        $isStraight = ($sortedRolls[0] + 1 == $sortedRolls[1] && $sortedRolls[1] + 1 == $sortedRolls[2]);
        $isStraight123 = ($sortedRolls[0] == 1 && $sortedRolls[1] == 2 && $sortedRolls[2] == 3);
        $hasPairs = ($rolls[0] == $rolls[1] || $rolls[0] == $rolls[2] || $rolls[1] == $rolls[2]);

        if ($isLeopard) {
            $winningAttributes[] = '豹子';
            $winningAttributes[] = "{$rolls[0]}豹子"; // Specific Leopard
        }
        if ($isStraight) $winningAttributes[] = '顺子';
        if ($isStraight123) $winningAttributes[] = '123顺子';
        if ($hasPairs && !$isLeopard) $winningAttributes[] = '对子';

        // Point Kill
        $winningAttributes[] = "{$sum}杀";

        // Dragon Tiger
        $dragonRoll = $rolls[0];
        $tigerRoll = $rolls[2];
        $isDragonWin = $dragonRoll > $tigerRoll;
        $isTigerWin = $tigerRoll > $dragonRoll;
        $isDragonTigerTie = $dragonRoll == $tigerRoll;

        if ($isDragonWin) $winningAttributes[] = '龙';
        if ($isTigerWin) $winningAttributes[] = '虎';
        if ($isDragonTigerTie) $winningAttributes[] = '合';


        // 2. Iterate through user bets to calculate result
        $totalProfit = 0;
        $totalWinAmount = 0;
        $totalBetAmount = 0;
        $resultLines = [];

        foreach ($bets as $bet) {
            $betData = $bet['bet_data'];
            $betAmount = $bet['bet_amount'];
            $totalBetAmount += $betAmount;
            
            $isWin = false;
            $refund = false;
            $reason = "";
            $betKey = "";
            $subProfit = 0;
            $subWinAmount = 0;

            // --- Apply "Leopard All Kill" rule first ---
            if ($isLeopard && $betData['type'] !== 'point_kill_leopard' && $betData['type'] !== 'point_kill') {
                $isWin = false;
                $reason = "豹子通杀! 😱";
                $subProfit = -$betAmount;
            } else {
                 switch ($betData['type']) {
                    case 'single':
                        switch ($betData['sub_type']) {
                            case 'big': $isWin = $isBig; $betKey = 'single_big_small'; break;
                            case 'small': $isWin = $isSmall; $betKey = 'single_big_small'; break;
                            case 'odd': $isWin = $isOdd; $betKey = 'single_odd_even'; break;
                            case 'even': $isWin = $isEven; $betKey = 'single_odd_even'; break;
                        }
                        break;
                    case 'compound':
                        switch ($betData['sub_type']) {
                            case 'big_odd': $isWin = $isBig && $isOdd; $betKey = 'compound_big_odd'; break;
                            case 'small_even': $isWin = $isSmall && $isEven; $betKey = 'compound_small_even'; break;
                            case 'big_even': $isWin = $isBig && $isEven; $betKey = 'compound_big_even'; break;
                            case 'small_odd': $isWin = $isSmall && $isOdd; $betKey = 'compound_small_odd'; break;
                        }
                        break;
                    case 'special':
                        switch ($betData['sub_type']) {
                            case 'pairs': $isWin = $hasPairs && !$isLeopard; $betKey = 'special_pairs'; break;
                            case 'leopard': $isWin = $isLeopard; $betKey = 'special_leopard'; break;
                            case 'straight': $isWin = $isStraight; $betKey = 'special_straight'; break;
                            case 'straight_123': $isWin = $isStraight123; $betKey = 'special_straight_123'; break;
                        }
                        break;
                    case 'point_kill':
                        $betSum = $betData['sum'];
                        $isWin = ($sum == $betSum);
                        $betKey = "point_kill_sum_{$betSum}";
                        break;
                    case 'point_kill_leopard':
                        $isWin = $isLeopard && ($rolls[0] == $betData['point']);
                        $betKey = 'point_kill_leopard';
                        break;
                    case 'dragon_tiger':
                        switch ($betData['sub_type']) {
                            case 'dragon': $isWin = $isDragonWin; $betKey = 'dragon_tiger_dragon_tiger'; break;
                            case 'tiger': $isWin = $isTigerWin; $betKey = 'dragon_tiger_dragon_tiger'; break;
                            case 'tie': $isWin = $isDragonTigerTie; $betKey = 'dragon_tiger_tie'; break;
                        }
                        break;
                }

                // Calculate sub-result
                if ($isWin && isset($this->odds[$betKey])) {
                    $subWinAmount = $betAmount * $this->odds[$betKey];
                    $subProfit = $subWinAmount - $betAmount;
                } elseif (!$isWin) {
                    $subProfit = -$betAmount;
                }

                 // --- Apply "Straight Refund" rule ---
                if ($isStraight && $betData['type'] !== 'special' || ($betData['type'] === 'special' && $betData['sub_type'] !== 'straight')) {
                    if ($isWin) { 
                        $refund = true;
                        $subWinAmount = $betAmount; 
                        $subProfit = 0;
                        $reason = "顺子回本";
                    } elseif ($subProfit < 0 && $reason == "") {
                         $reason = "顺子吃";
                    }
                }
            }

            $totalProfit += $subProfit;
            $totalWinAmount += $subWinAmount;
            
            // Format result line for this bet
            $betName = $this->getBetTypeDisplay($betData);
            
            // Check if this specific bet won (for highlighting)
            $resIcon = "";
            $resText = "";
            
            if ($subProfit > 0) {
                 $resIcon = "✅";
                 $resText = "+{$subProfit}";
                 $resultLines[] = "{$resIcon} <b>{$betName}</b>: <code>{$resText}</code>"; // Highlight win amount
            } elseif ($refund) {
                 $resIcon = "🛡";
                 $resText = "回本";
                 $resultLines[] = "{$resIcon} {$betName}: {$resText}";
            } else {
                 $resIcon = "❌";
                 $resText = "-{$betAmount}";
                 if ($reason) $resText .= " ({$reason})";
                 $resultLines[] = "{$resIcon} {$betName}: {$resText}";
            }

            // Determine specific result type for this bet's history (simplified)
            $histResultType = '';
            if ($isLeopard) $histResultType = '豹子';
            elseif ($isStraight123) $histResultType = '123顺子';
            elseif ($isStraight) $histResultType = '顺子';
            else $histResultType = $sum; 
            
            // Record History per bet
            GameHistory::create([
                'telegram_id' => $userId,
                'username' => $username,
                'bet_type' => $betName,
                'bet_amount' => $betAmount,
                'win_amount' => $subWinAmount,
                'profit' => $subProfit,
                'result_type' => $histResultType, 
                'rolls' => json_encode($rolls),
            ]);
        }
        
        // Update User Balance
        $user = TelegramUser::where('telegram_id', $userId)->first();
        if ($totalWinAmount > 0) {
            $user->balance += $totalWinAmount;
            $user->save();
        }

        // Message Construction
        $diceEmojis = [1 => '1️⃣', 2 => '2️⃣', 3 => '3️⃣', 4 => '4️⃣', 5 => '5️⃣', 6 => '6️⃣'];
        $rollStr = implode('  ', array_map(fn($v) => $diceEmojis[$v], $rolls));
        
        // Highlight winning attributes
        $winningStr = implode(' ', array_map(fn($attr) => "<code>{$attr}</code>", $winningAttributes));

        // Use bet summary for the message
        $betSummary = $this->formatBetSummary($bets);

        $msg = "🎰 <b>开奖结果</b>\n" .
               "━━━━━━━━━━━━━━━━\n" .
               "👤 玩家: @{$username}\n" .
               "🎲 骰子: {$rollStr}\n" .
               "🔢 总点: <b>{$sum}点</b>\n" .
               "🏆 <b>{$winningStr}</b>\n" . // Show all winning attributes
               "━━━━━━━━━━━━━━━━\n" .
               implode("\n", $resultLines) . "\n" .
               "━━━━━━━━━━━━━━━━\n";

        if ($totalProfit > 0) {
            $msg .= "🏆 <b>总盈利: <code>+{$totalProfit}</code></b>\n";
        } elseif ($totalProfit < 0) {
            $loss = abs($totalProfit);
            $msg .= "💸 <b>总亏损: -{$loss}</b>\n";
        } else {
             $msg .= "🛡 <b>平局 (无盈亏)</b>\n";
        }

        $msg .= "💰 余额: <b>{$user->balance}</b>";

        // Add Stats Button to Result
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📊 我的今日统计', 'callback_data' => 'my_stats'],
                ]
            ]
        ];

        $this->sendMessage($chatId, $msg, true, 'HTML', $keyboard);
    }

    // --- Helpers ---

    protected function sendDice($chatId)
    {
        $response = $this->telegramHttp()->post("{$this->apiUrl}{$this->botToken}/sendDice", [
            'chat_id' => $chatId,
            'emoji' => '🎲'
        ]);

        if ($response->successful()) {
            return $response->json('result.dice.value');
        }
        
        // Fallback if Telegram API fails or for testing
        return rand(1, 6);
    }

    protected function sendMessage($chatId, $text, $replyToMessageId = null, $parseMode = null, $replyMarkup = null)
    {
        $params = ['chat_id' => $chatId, 'text' => $text];
        if ($replyToMessageId && !is_bool($replyToMessageId)) {
             $params['reply_to_message_id'] = $replyToMessageId;
        }
        if ($parseMode) $params['parse_mode'] = $parseMode;
        if ($replyMarkup) $params['reply_markup'] = $replyMarkup;
        $response = $this->telegramHttp()->post("{$this->apiUrl}{$this->botToken}/sendMessage", $params);

        if (!$response->successful()) {
            Log::error('Telegram sendMessage failed.', [
                'chat_id' => $chatId,
                'status' => $response->status(),
                'response' => $response->json(),
            ]);
        }

        return $response->successful();
    }
    
    protected function answerCallback($callbackQueryId, $text, $showAlert = false)
    {
        $response = $this->telegramHttp()->post("{$this->apiUrl}{$this->botToken}/answerCallbackQuery", [
            'callback_query_id' => $callbackQueryId,
            'text' => $text,
            'show_alert' => $showAlert
        ]);

        if (!$response->successful()) {
            Log::error('Telegram answerCallbackQuery failed.', [
                'status' => $response->status(),
                'response' => $response->json(),
            ]);
        }

        return $response->successful();
    }

    protected function isAdmin($id)
    {
        $allAdmins = array_merge($this->adminIds, explode(',', env('TELEGRAM_ADMIN_IDS', '')));
        return in_array((string)$id, array_map('trim', $allAdmins));
    }

    protected function handleAdminCharge($chatId, $text, $message)
    {
        $targetId = null;
        $targetName = '';
        $amount = 0;

        // 1. Try to find @username and Number (Support + and -)
        // Matches: "@user +100", "-100 @user"
        $uName = null;
        if (preg_match('/@(\w+)\s+([+-]?\d+)/u', $text, $m)) {
            $uName = $m[1];
            $amount = (int)$m[2];
        } elseif (preg_match('/([+-]?\d+)\s+@(\w+)/u', $text, $m)) {
            $amount = (int)$m[1];
            $uName = $m[2];
        } elseif (preg_match('/@(\w+).*?([+-]?\d+)/u', $text, $m)) { 
             $uName = $m[1];
             $amount = (int)$m[2];
        }
        
        if ($uName) {
            $user = TelegramUser::where('username', $uName)->first();
            if ($user) {
                $targetId = $user->telegram_id;
                $targetName = $user->username;
            } else {
                $this->sendMessage($chatId, "⚠️ 找不到用户 @{$uName}");
                return;
            }
        } 
        // 2. Reply Mode (Reply + "-100" or "+100")
        elseif (isset($message['reply_to_message']) && preg_match('/([+-]?\d+)/', $text, $matches)) {
             $amount = (int)$matches[1];
             $targetId = $message['reply_to_message']['from']['id'];
             $targetName = $message['reply_to_message']['from']['username'] ?? $message['reply_to_message']['from']['first_name'];
        }

        if ($targetId && $amount != 0) {
            $user = TelegramUser::firstOrCreate(['telegram_id' => $targetId], ['username' => $targetName, 'balance' => 0]);
            $user->balance += $amount;
            $user->save();
            
            $sign = $amount > 0 ? '+' : ''; // Display explicit + for positive
            $this->sendMessage($chatId, "✅ 余额调整成功!\n用户: @{$targetName}\n变动: {$sign}{$amount}\n余额: {$user->balance}");
        }
    }
}
