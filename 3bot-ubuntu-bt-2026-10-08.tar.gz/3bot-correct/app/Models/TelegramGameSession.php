<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramGameSession extends Model
{
    protected $fillable = [
        'telegram_id',
        'chat_id',
        'username',
        'reserved_amount',
        'session_data',
    ];

    protected $casts = [
        'telegram_id' => 'integer',
        'chat_id' => 'integer',
        'reserved_amount' => 'decimal:2',
        'session_data' => 'array',
    ];
}
