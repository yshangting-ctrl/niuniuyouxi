<?php

use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\AdminAuthController;
use App\Models\TelegramUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

Route::get('/admin/login', [AdminAuthController::class, 'showLogin'])->name('admin.login');
Route::get('/admin/captcha', [AdminAuthController::class, 'captcha'])->name('admin.captcha');
Route::post('/admin/login', [AdminAuthController::class, 'login'])->name('admin.login.submit');
Route::post('/admin/logout', [AdminAuthController::class, 'logout'])->name('admin.logout')->middleware('admin.auth');

Route::middleware('admin.auth')->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
    Route::get('/admin', [AdminDashboardController::class, 'index']);

    Route::post('/admin/users/{telegramUser}/balance', function (Request $request, TelegramUser $telegramUser) {
        $data = $request->validate([
            'amount' => ['required', 'numeric', 'between:-1000000,1000000'],
        ]);

        $amount = (float) $data['amount'];
        $newBalance = (float) $telegramUser->balance + $amount;

        if ($newBalance < 0) {
            return back()->withErrors(['amount' => '余额不能低于 0。']);
        }

        DB::transaction(function () use ($telegramUser, $amount) {
            $telegramUser->increment('balance', $amount);
        });

        $verb = $amount >= 0 ? '增加' : '扣除';
        return back()->with('status', "已为 @{$telegramUser->username} {$verb} " . number_format(abs($amount), 2) . ' 积分。');
    })->name('admin.users.balance');
});
