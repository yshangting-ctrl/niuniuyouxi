<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\TelegramUser;
use Illuminate\Support\Str;

class GameCli extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'game:start';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Start the interactive Dice Game CLI';

    /**
     * 当前登录的用户模型实例
     *
     * @var \App\Models\TelegramUser|null
     */
    protected $user;

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info("欢迎来到虚拟积分骰子游戏 CLI 版！");

        while (true) {
            // 1. 模拟登录流程
            if (!$this->user) {
                $this->login();
            }

            // 2. 显示主菜单
            $this->showMenu();
        }
    }

    /**
     * 模拟登录：询问 ID 并获取或创建用户
     */
    protected function login()
    {
        $this->newLine();
        $telegramId = $this->ask('请输入您的 User ID (数字) 进行模拟登录');

        // 简单的输入验证
        if (!is_numeric($telegramId)) {
            $this->error('User ID 必须是数字！');
            return;
        }

        // 查找或创建用户
        $this->user = TelegramUser::firstOrCreate(
            ['telegram_id' => $telegramId],
            [
                'username' => 'User_' . $telegramId,
                'balance' => 0
            ]
        );

        $this->info("登录成功！欢迎回来，{$this->user->username} (余额: {$this->user->balance})");
    }

    /**
     * 显示主菜单并处理选择
     */
    protected function showMenu()
    {
        $this->newLine();
        $option = $this->choice(
            '请选择操作',
            [
                '1' => '查看当前余额 (Check Balance)',
                '2' => '玩一把 (Play Dice)',
                '3' => '管理员上分/下分 (Admin Manage Points)',
                '4' => '退出 (Exit)',
                '5' => '切换账号 (Logout)',
            ],
            '2' // 默认选项
        );

        switch ($option) {
            case '1':
            case '查看当前余额 (Check Balance)':
                $this->checkBalance();
                break;
            case '2':
            case '玩一把 (Play Dice)':
                $this->playDice();
                break;
            case '3':
            case '管理员上分/下分 (Admin Manage Points)':
                $this->adminManage();
                break;
            case '4':
            case '退出 (Exit)':
                $this->info('感谢游玩，再见！');
                exit(0);
            case '5':
            case '切换账号 (Logout)':
                $this->user = null;
                $this->info('已登出。');
                break;
        }
    }

    /**
     * 查看余额
     */
    protected function checkBalance()
    {
        // 刷新模型数据以获取最新余额
        $this->user->refresh();
        $this->info("您的当前余额为: {$this->user->balance}");
    }

    /**
     * 核心游戏逻辑：玩一把
     */
    protected function playDice()
    {
        $this->user->refresh();
        $balance = $this->user->balance;

        $this->info("--- 新的游戏局 ---");
        $this->info("当前余额: $balance");

        // 1. 选择押注类型
        $betType = $this->choice('请下注', ['大 (Big)', '小 (Small)'], 0);
        // 简化判断逻辑，取第一个字符或根据选项判断
        $isBig = str_contains($betType, '大') || str_contains($betType, 'Big');
        $targetStr = $isBig ? '大' : '小';

        // 2. 输入下注金额
        $amount = $this->ask('请输入下注积分数量');

        // 验证金额
        if (!is_numeric($amount) || $amount <= 0) {
            $this->error('无效的金额，请输入正数。');
            return;
        }

        if ($amount > $balance) {
            $this->error("余额不足！您只有 $balance 积分。");
            return;
        }

        // 3. 生成骰子结果
        $dice1 = rand(1, 6);
        $dice2 = rand(1, 6);
        $dice3 = rand(1, 6);
        $sum = $dice1 + $dice2 + $dice3;

        // 4. 判断结果 (3-10 小, 11-18 大)
        $resultStr = ($sum >= 11 && $sum <= 18) ? '大' : '小';
        $win = ($resultStr === $targetStr);

        // 5. 展示结果
        $this->newLine();
        $this->table(
            ['骰子 1', '骰子 2', '骰子 3', '总点数', '结果'],
            [
                [$dice1, $dice2, $dice3, $sum, $resultStr]
            ]
        );

        // 6. 结算与数据库更新
        if ($win) {
            // 赢：获得本金 + 1倍赔率 (即余额增加 1倍下注额)
            // 比如有100，下注10。赢了变110。
            // 逻辑：余额 = 余额 + 下注额
            $this->user->balance += $amount;
            $this->user->save();
            $this->info("恭喜你！猜对了！获得 $amount 积分。");
        } else {
            // 输：扣除本金
            // 逻辑：余额 = 余额 - 下注额
            $this->user->balance -= $amount;
            $this->user->save();
            $this->error("很遗憾，猜错了。扣除 $amount 积分。");
        }

        $this->info("最新余额: {$this->user->balance}");
    }

    /**
     * 管理员功能
     */
    protected function adminManage()
    {
        $password = $this->secret('请输入管理员密码');

        if ($password !== 'admin888') {
            $this->error('密码错误！');
            return;
        }

        $targetId = $this->ask('请输入目标用户的 User ID (telegram_id)');
        $targetUser = TelegramUser::where('telegram_id', $targetId)->first();

        if (!$targetUser) {
            $this->error("未找到 ID 为 $targetId 的用户。");
            return;
        }

        $this->info("当前用户 {$targetUser->username} 余额: {$targetUser->balance}");
        $changeAmount = $this->ask('请输入变动金额 (正数为加分，负数为扣分)');

        if (!is_numeric($changeAmount)) {
            $this->error('金额必须是数字。');
            return;
        }

        try {
            $targetUser->balance += $changeAmount;
            $targetUser->save();
            $this->info("操作成功！用户 {$targetUser->username} 最新余额: {$targetUser->balance}");
        } catch (\Exception $e) {
            $this->error('操作失败: ' . $e->getMessage());
        }
    }
}
