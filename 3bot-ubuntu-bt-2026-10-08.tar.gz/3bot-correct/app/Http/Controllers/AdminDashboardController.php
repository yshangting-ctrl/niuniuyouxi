<?php

namespace App\Http\Controllers;

use App\Models\GameHistory;
use App\Models\TelegramUser;
use Carbon\CarbonPeriod;
use Illuminate\Support\Carbon;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $today = Carbon::today();
        $weekStart = $today->copy()->subDays(6);

        $dailyGames = GameHistory::query()
            ->whereBetween('created_at', [$weekStart->copy()->startOfDay(), $today->copy()->endOfDay()])
            ->selectRaw("date(created_at) as day, count(*) as games, coalesce(sum(bet_amount), 0) as turnover, coalesce(sum(profit), 0) as profit")
            ->groupBy('day')
            ->orderBy('day')
            ->get()
            ->keyBy('day');

        $dailySeries = [];
        foreach (CarbonPeriod::create($weekStart, $today) as $date) {
            $key = $date->toDateString();
            $row = $dailyGames->get($key);
            $dailySeries[] = [
                'label' => $date->isoFormat('ddd'),
                'date' => $date->format('m/d'),
                'games' => (int) ($row->games ?? 0),
                'turnover' => (float) ($row->turnover ?? 0),
                'profit' => (float) ($row->profit ?? 0),
            ];
        }

        $stats = [
            'players' => TelegramUser::count(),
            'active_players' => TelegramUser::where('updated_at', '>=', now()->subDay())->count(),
            'balance' => (float) TelegramUser::sum('balance'),
            'turnover' => (float) GameHistory::whereDate('created_at', $today)->sum('bet_amount'),
            'profit' => (float) GameHistory::whereDate('created_at', $today)->sum('profit'),
            'games' => GameHistory::whereDate('created_at', $today)->count(),
        ];

        return view('dashboard', [
            'stats' => $stats,
            'dailySeries' => $dailySeries,
            'recentUsers' => TelegramUser::latest('updated_at')->take(8)->get(),
            'recentGames' => GameHistory::latest()->take(8)->get(),
            'botConfigured' => filled(env('TELEGRAM_BOT_TOKEN')),
        ]);
    }
}
