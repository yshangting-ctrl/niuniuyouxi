<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>3Bot 控制台</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="admin-shell">
<div class="app-layout">
    <aside class="sidebar" id="sidebar">
        <div class="brand-lockup">
            <span class="brand-mark">3</span>
            <span><strong>3BOT</strong><small>运营控制台</small></span>
        </div>
        <div class="workspace-switcher">
            <span class="workspace-icon">◈</span>
            <span><small>当前工作区</small><strong>Telegram Bot</strong></span>
            <span class="workspace-chevron">⌄</span>
        </div>
        <nav class="sidebar-nav" aria-label="主导航">
            <p class="nav-heading">工作台</p>
            <a class="nav-link is-active" href="#overview" data-section-link><span class="nav-icon">◉</span>概览</a>
            <a class="nav-link" href="#players" data-section-link><span class="nav-icon">♙</span>玩家与余额</a>
            <a class="nav-link" href="#games" data-section-link><span class="nav-icon">▦</span>游戏记录</a>
            <p class="nav-heading nav-heading-spaced">运营</p>
            <a class="nav-link" href="#operations" data-section-link><span class="nav-icon">⌁</span>运营工具</a>
            <a class="nav-link" href="#settings" data-section-link><span class="nav-icon">⚙</span>系统设置</a>
        </nav>
        <div class="sidebar-footer">
            <div class="bot-status">
                <span class="status-dot"></span>
                <span><strong>机器人在线</strong><small>{{ $botConfigured ? 'Token 已配置' : '等待 Token' }}</small></span>
            </div>
            <div class="admin-profile">
                <span class="profile-avatar">管</span>
                <span><strong>管理员</strong><small>ID 8539427848</small></span>
                <form method="POST" action="{{ route('admin.logout') }}">
                    @csrf
                    <button class="icon-button" type="submit" title="退出登录" aria-label="退出登录">↪</button>
                </form>
            </div>
        </div>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="topbar-title">
                <button class="mobile-menu-button" id="menuToggle" type="button" title="打开导航" aria-label="打开导航">☰</button>
                <div><p class="breadcrumb">运营中心 <span>/</span> 总览</p><h1>机器人控制台</h1></div>
            </div>
            <div class="topbar-actions">
                <span class="last-sync">数据来自本地 SQLite · {{ now()->format('H:i') }} 更新</span>
                <button class="button button-quiet" type="button" id="refreshButton"><span>↻</span>刷新</button>
                <button class="button button-primary" type="button" data-open-balance><span>＋</span>调整余额</button>
            </div>
        </header>

        <div class="page-content">
            @if (session('status'))
                <div class="toast toast-success" role="status">✓ {{ session('status') }}</div>
            @endif
            @if ($errors->any())
                <div class="toast toast-error" role="alert">{{ $errors->first() }}</div>
            @endif

            <section class="page-section is-visible" id="overview">
                <div class="hero-banner">
                    <div>
                        <p class="section-kicker">今日运营脉搏</p>
                        <h2>每一局，都值得被看见。</h2>
                        <p class="hero-copy">掌握玩家余额、投注流水和机器人状态，把日常运营集中在一个清晰的工作台里。</p>
                    </div>
                    <div class="hero-summary">
                        <span class="hero-summary-label">今日对局</span>
                        <strong>{{ number_format($stats['games']) }}</strong>
                        <span class="hero-summary-change">{{ $stats['active_players'] }} 位玩家近 24 小时活跃</span>
                    </div>
                </div>

                <div class="metric-grid">
                    <article class="metric-card"><div class="metric-topline"><span class="metric-label">玩家总数</span><span class="metric-icon metric-icon-blue">♙</span></div><strong class="metric-value">{{ number_format($stats['players']) }}</strong><span class="metric-note"><b>{{ number_format($stats['active_players']) }}</b> 近 24 小时活跃</span></article>
                    <article class="metric-card"><div class="metric-topline"><span class="metric-label">平台余额</span><span class="metric-icon metric-icon-green">◈</span></div><strong class="metric-value">{{ number_format($stats['balance'], 2) }}</strong><span class="metric-note">所有玩家积分余额合计</span></article>
                    <article class="metric-card"><div class="metric-topline"><span class="metric-label">今日流水</span><span class="metric-icon metric-icon-orange">↗</span></div><strong class="metric-value">{{ number_format($stats['turnover'], 2) }}</strong><span class="metric-note">{{ number_format($stats['games']) }} 局已记录</span></article>
                    <article class="metric-card"><div class="metric-topline"><span class="metric-label">今日净盈亏</span><span class="metric-icon metric-icon-purple">≈</span></div><strong class="metric-value {{ $stats['profit'] < 0 ? 'is-negative' : '' }}">{{ $stats['profit'] >= 0 ? '+' : '' }}{{ number_format($stats['profit'], 2) }}</strong><span class="metric-note">根据游戏记录实时汇总</span></article>
                </div>

                <div class="content-grid overview-grid">
                    <section class="panel chart-panel">
                        <div class="panel-heading"><div><p class="panel-eyebrow">活动趋势</p><h3>近 7 日投注流水</h3></div><span class="panel-period">{{ $dailySeries[0]['date'] }} — {{ $dailySeries[6]['date'] }}</span></div>
                        @php($maxTurnover = max(1, max(array_column($dailySeries, 'turnover'))))
                        <div class="chart-area" aria-label="近七日投注流水柱状图">
                            <div class="chart-y-axis"><span>{{ number_format($maxTurnover, 0) }}</span><span>{{ number_format($maxTurnover / 2, 0) }}</span><span>0</span></div>
                            <div class="bar-chart">
                                @foreach ($dailySeries as $day)
                                    @php($height = $day['turnover'] > 0 ? max(8, ($day['turnover'] / $maxTurnover) * 100) : 5)
                                    <div class="bar-column" title="{{ $day['date'] }} · 流水 {{ number_format($day['turnover'], 2) }}"><div class="bar-value">{{ $day['turnover'] > 0 ? number_format($day['turnover'], 0) : '—' }}</div><div class="bar-track"><span class="bar-fill" style="height: {{ $height }}%"></span></div><span class="bar-label">{{ $day['label'] }}</span></div>
                                @endforeach
                            </div>
                        </div>
                    </section>
                    <section class="panel status-panel">
                        <div class="panel-heading"><div><p class="panel-eyebrow">运行状态</p><h3>服务检查</h3></div><span class="live-pill"><i></i>在线</span></div>
                        <div class="status-list">
                            <div class="status-row"><span class="status-row-icon">TG</span><span><strong>Telegram 长轮询</strong><small>接收消息与下注事件</small></span><b class="status-ok">正常</b></div>
                            <div class="status-row"><span class="status-row-icon">DB</span><span><strong>SQLite 数据库</strong><small>用户、余额、游戏记录</small></span><b class="status-ok">正常</b></div>
                            <div class="status-row"><span class="status-row-icon">TR</span><span><strong>TRC20 钱包模块</strong><small>充值地址生成</small></span><b class="status-warn">待配置</b></div>
                        </div>
                        <button class="text-button" type="button" data-scroll-to="operations">查看运营工具 <span>→</span></button>
                    </section>
                </div>
            </section>

            <section class="page-section" id="players">
                <div class="section-header"><div><p class="section-kicker">账户管理</p><h2>玩家与余额</h2><p>查看玩家状态，快速完成积分调整。</p></div><button class="button button-primary" type="button" data-open-balance><span>＋</span>调整余额</button></div>
                <section class="panel table-panel">
                    <div class="table-toolbar"><div class="search-field"><span>⌕</span><input id="playerSearch" type="search" placeholder="搜索用户名或 Telegram ID" aria-label="搜索玩家"></div><span class="table-count">{{ $recentUsers->count() }} 条最近记录</span></div>
                    <div class="table-scroll"><table class="data-table" id="playersTable"><thead><tr><th>玩家</th><th>Telegram ID</th><th>余额</th><th>钱包状态</th><th>最近活动</th><th></th></tr></thead><tbody>
                    @forelse ($recentUsers as $user)
                        <tr data-player-row data-search="{{ strtolower($user->username . ' ' . $user->telegram_id) }}"><td><div class="person-cell"><span class="person-avatar">{{ mb_substr($user->username ?: 'U', 0, 1) }}</span><span><strong>{{ $user->username ?: '未设置用户名' }}</strong><small>玩家账号</small></span></div></td><td class="mono-cell">{{ $user->telegram_id }}</td><td><strong class="balance-cell">{{ number_format((float) $user->balance, 2) }}</strong></td><td><span class="tag {{ $user->wallet_address ? 'tag-green' : 'tag-muted' }}">{{ $user->wallet_address ? '已生成钱包' : '未生成钱包' }}</span></td><td class="muted-cell">{{ $user->updated_at?->diffForHumans() ?: '暂无活动' }}</td><td><button class="table-action" type="button" data-balance-user="{{ $user->id }}" data-balance-name="{{ $user->username ?: $user->telegram_id }}">调整</button></td></tr>
                    @empty
                        <tr><td colspan="6" class="empty-state">还没有玩家记录。玩家在 Telegram 发送充值或下注命令后会出现在这里。</td></tr>
                    @endforelse
                    </tbody></table></div>
                </section>
            </section>

            <section class="page-section" id="games">
                <div class="section-header"><div><p class="section-kicker">审计与分析</p><h2>游戏记录</h2><p>按时间检查每一局的下注、结果和盈亏。</p></div><span class="section-meta">今日 {{ number_format($stats['games']) }} 局</span></div>
                <section class="panel table-panel"><div class="table-scroll"><table class="data-table"><thead><tr><th>时间</th><th>玩家</th><th>玩法</th><th>下注</th><th>结果</th><th>盈亏</th></tr></thead><tbody>
                @forelse ($recentGames as $game)
                    <tr><td class="muted-cell">{{ $game->created_at?->format('m-d H:i') }}</td><td><strong>{{ $game->username ?: $game->telegram_id }}</strong></td><td><span class="game-type">{{ $game->bet_type }}</span></td><td>{{ number_format((float) $game->bet_amount, 2) }}</td><td>{{ $game->result_type ?: '—' }}</td><td class="{{ (float) $game->profit >= 0 ? 'profit-positive' : 'profit-negative' }}">{{ (float) $game->profit >= 0 ? '+' : '' }}{{ number_format((float) $game->profit, 2) }}</td></tr>
                @empty
                    <tr><td colspan="6" class="empty-state">还没有游戏记录。玩家完成第一局后，结果会自动显示在这里。</td></tr>
                @endforelse
                </tbody></table></div></section>
            </section>

            <section class="page-section" id="operations">
                <div class="section-header"><div><p class="section-kicker">日常动作</p><h2>运营工具</h2><p>把高频的机器人运营动作放在手边。</p></div></div>
                <div class="operation-grid">
                    <article class="operation-card"><span class="operation-icon operation-icon-blue">＋</span><div><h3>调整玩家余额</h3><p>为指定玩家增加或扣除积分，变更会立即写入数据库。</p><button class="text-button" type="button" data-open-balance>打开工具 <span>→</span></button></div></article>
                    <article class="operation-card"><span class="operation-icon operation-icon-green">↗</span><div><h3>机器人快捷命令</h3><p>使用 Telegram 的 <code>/start</code>、<code>/menu</code>、<code>/balance</code> 和 <code>/history</code>。</p><button class="text-button" type="button" data-copy="/menu">复制 /menu <span>↗</span></button></div></article>
                    <article class="operation-card"><span class="operation-icon operation-icon-orange">!</span><div><h3>充值与风控</h3><p>当前只生成 TRC20 地址，自动扫描上分尚未接入，请谨慎处理真实资金。</p><button class="text-button" type="button" data-scroll-to="settings">查看配置说明 <span>→</span></button></div></article>
                </div>
            </section>

            <section class="page-section" id="settings">
                <div class="section-header"><div><p class="section-kicker">环境与边界</p><h2>系统设置</h2><p>当前实例的运行参数和能力边界。</p></div></div>
                <div class="settings-grid"><div class="settings-item"><span>运行环境</span><strong>Local / SQLite</strong></div><div class="settings-item"><span>Telegram Token</span><strong class="settings-ok">已配置</strong></div><div class="settings-item"><span>管理员 ID</span><strong>8539427848</strong></div><div class="settings-item"><span>充值扫描器</span><strong class="settings-warn">未接入</strong></div></div>
            </section>
        </div>
    </main>
</div>

<div class="modal-backdrop" id="balanceModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="balanceModalTitle">
        <div class="modal-heading"><div><p class="panel-eyebrow">账户操作</p><h2 id="balanceModalTitle">调整玩家余额</h2></div><button class="icon-button modal-close" type="button" data-close-balance title="关闭" aria-label="关闭">×</button></div>
        <p class="modal-copy">输入正数上分，输入负数扣分。调整会立即写入本地数据库。</p>
        <form method="POST" id="balanceForm" action="{{ $recentUsers->first() ? route('admin.users.balance', $recentUsers->first()) : '#' }}">
            @csrf
            <label class="form-label" for="balanceUser">玩家</label>
            <select class="form-control" id="balanceUser" name="user_id" required>
                @forelse ($recentUsers as $user)
                    <option value="{{ $user->id }}" data-action="{{ route('admin.users.balance', $user) }}">{{ $user->username ?: $user->telegram_id }} · {{ $user->telegram_id }}</option>
                @empty
                    <option value="">暂无玩家</option>
                @endforelse
            </select>
            <label class="form-label" for="balanceAmount">变更积分</label>
            <input class="form-control" id="balanceAmount" name="amount" type="number" step="0.01" placeholder="例如 100 或 -50" required>
            <div class="modal-actions"><button class="button button-quiet" type="button" data-close-balance>取消</button><button class="button button-primary" type="submit">确认调整</button></div>
        </form>
    </div>
</div>
</body>
</html>
