import './bootstrap';

const ready = (callback) => {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', callback, { once: true });
    } else {
        callback();
    }
};

ready(() => {
    const sidebar = document.querySelector('#sidebar');
    const menuToggle = document.querySelector('#menuToggle');
    const modal = document.querySelector('#balanceModal');
    const form = document.querySelector('#balanceForm');
    const userSelect = document.querySelector('#balanceUser');
    const amountInput = document.querySelector('#balanceAmount');
    const searchInput = document.querySelector('#playerSearch');

    const closeSidebar = () => sidebar?.classList.remove('is-open');
    const closeModal = () => {
        if (!modal) return;
        modal.hidden = true;
        document.body.style.overflow = '';
    };

    const openModal = (userId = null, userName = '') => {
        if (!modal) return;
        if (userId && userSelect) {
            userSelect.value = String(userId);
        }
        if (userSelect && form) {
            const selected = userSelect.options[userSelect.selectedIndex];
            const action = selected?.dataset.action;
            if (action) form.action = action;
        }
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        window.setTimeout(() => {
            if (userId) amountInput?.focus();
            else userSelect?.focus();
        }, 30);
        if (userName && userSelect) userSelect.setAttribute('aria-label', `玩家：${userName}`);
    };

    menuToggle?.addEventListener('click', () => sidebar?.classList.toggle('is-open'));
    document.querySelectorAll('[data-section-link]').forEach((link) => {
        link.addEventListener('click', (event) => {
            event.preventDefault();
            const id = link.getAttribute('href')?.slice(1);
            if (!id) return;
            document.querySelectorAll('.page-section').forEach((section) => section.classList.toggle('is-visible', section.id === id));
            document.querySelectorAll('[data-section-link]').forEach((item) => item.classList.toggle('is-active', item === link));
            history.replaceState(null, '', `#${id}`);
            closeSidebar();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

    const initialSection = window.location.hash.slice(1);
    if (initialSection && document.getElementById(initialSection)) {
        document.querySelector(`[data-section-link][href="#${initialSection}"]`)?.click();
    }

    document.querySelectorAll('[data-open-balance]').forEach((button) => {
        button.addEventListener('click', () => openModal(button.dataset.balanceUser, button.dataset.balanceName));
    });
    document.querySelectorAll('[data-balance-user]').forEach((button) => {
        button.addEventListener('click', () => openModal(button.dataset.balanceUser, button.dataset.balanceName));
    });
    document.querySelectorAll('[data-close-balance]').forEach((button) => button.addEventListener('click', closeModal));
    modal?.addEventListener('click', (event) => {
        if (event.target === modal) closeModal();
    });
    userSelect?.addEventListener('change', () => {
        const selected = userSelect.options[userSelect.selectedIndex];
        if (selected?.dataset.action && form) form.action = selected.dataset.action;
    });
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeModal();
            closeSidebar();
        }
    });

    searchInput?.addEventListener('input', () => {
        const query = searchInput.value.trim().toLowerCase();
        document.querySelectorAll('[data-player-row]').forEach((row) => {
            row.hidden = query !== '' && !(row.dataset.search || '').includes(query);
        });
    });

    document.querySelector('#refreshButton')?.addEventListener('click', () => window.location.reload());
    document.querySelectorAll('[data-scroll-to]').forEach((button) => {
        button.addEventListener('click', () => document.querySelector(`[data-section-link][href="#${button.dataset.scrollTo}"]`)?.click());
    });
    document.querySelectorAll('[data-copy]').forEach((button) => {
        button.addEventListener('click', async () => {
            const value = button.dataset.copy || '';
            try {
                await navigator.clipboard.writeText(value);
                showNotice(`${value} 已复制`);
            } catch {
                showNotice(`请手动输入 ${value}`);
            }
        });
    });

    document.querySelectorAll('[data-refresh-captcha]').forEach((button) => {
        button.addEventListener('click', () => {
            const image = button.querySelector('[data-captcha-image]');
            if (image) image.src = `${image.src.split('?')[0]}?v=${Date.now()}`;
            document.querySelector('#captcha')?.focus();
        });
    });

    function showNotice(message) {
        const notice = document.createElement('div');
        notice.className = 'toast toast-success';
        notice.textContent = `✓ ${message}`;
        notice.style.position = 'fixed';
        notice.style.right = '24px';
        notice.style.bottom = '24px';
        notice.style.zIndex = '90';
        document.body.appendChild(notice);
        window.setTimeout(() => notice.remove(), 2200);
    }
});
